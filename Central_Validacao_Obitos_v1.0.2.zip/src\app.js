(function () {
  "use strict";
  const C = window.CVConfig, U = window.CVUtils, Rules = window.CVRules, Validation = window.CVValidation;
  const Analytics = window.CVAnalytics, Charts = window.CVCharts, Reports = window.CVReports, Exports = window.CVExports, Table = window.CVTable;
  const TABLE_LIMIT = 20;
  let legacyHistoryDetected = false;
  let tableRenderTimer = null;
  const busyState = { startedAt: 0, percent: 0, timer: null };

  const state = {
    competence: new Date().toISOString().slice(0, 7),
    baseFile: null, returnFile: null, baseWorkbook: null, returnWorkbook: null,
    baseValidation: null, returnValidation: null, records: [], summary: null,
    history: loadHistory(),
    settings: loadSettings()
  };

  const demoBase = [["Matrícula Petros","Nome Participante","Nome Patrocinador","Data Nascimento","Idade","Logradouro","Número","Complemento","Bairro","Cidade","CEP","UF","País","Data Óbito","Nome Plano","Situação","Tipo Benefício"],
    ["000123","Ana Ribeiro","Petrobras","15/04/1948","78","Rua A","10","","Centro","Rio de Janeiro","20000-000","RJ","Brasil","","Plano Petros 2","Assistido","Aposentadoria"],
    ["000124","Bruno Lima","Petrobras","22/08/1952","73","Rua B","20","","Copacabana","Rio de Janeiro","22000-000","RJ","Brasil","","Plano Petros 2","Assistido","Pensão"],
    ["000125","Carla Souza","BR Distribuidora","10/01/1961","65","Rua C","30","","Boa Viagem","Recife","50000-000","PE","Brasil","","Plano PPSP-R","Ativo","Aposentadoria"],
    ["000126","Daniel Rocha","Petrobras","04/06/1942","84","Rua D","40","","Centro","Salvador","40000-000","BA","Brasil","","Plano PPSP-NR","Assistido","Aposentadoria"],
    ["000127","Elisa Martins","Petrobras","27/11/1970","55","Rua E","50","","Savassi","Belo Horizonte","30000-000","MG","Brasil","","Plano Petros 2","Ativo","Aposentadoria"],
    ["000128","Fabio Nunes","Transpetro","19/03/1958","68","Rua F","60","","Centro","Vitória","29000-000","ES","Brasil","","Plano Petros 2","Assistido","Aposentadoria"],
    ["000129","Gisele Alves","Petrobras","31/12/1939","86","Rua G","70","","Centro","Curitiba","80000-000","PR","Brasil","12/02/2025","Plano PPSP-R","Assistido","Pensão"],
    ["000130","Helena Costa","Petrobras","02/05/1965","61","Rua H","80","","Centro","São Paulo","01000-000","SP","Brasil","","Plano Petros 2","Ativo","Aposentadoria"]];
  const demoReturn = [["ID","Matrícula Petros","Nome Participante","Data Nascimento","CPF","Data Óbito","Pessoa Politicamente Exposta","CPF_ENRIQUECIDO","NOME_ENRIQUECIDO","SEXO_ENRIQUECIDO","DATA_NASC_ENRIQUECIDO","PPE_ENRIQUECIDO","OBITO_ENRIQUECIDO","DATA_OBITO_ENRIQUECIDO","ANO_OBITO","NOME_ORGAO","DESCRICAO_FUNCAO","DATA_INICIO_EXERCICIO","DATA_FIM_CARREIRA","POSSIVEL_OBITO_ENRIQUECIDO","DATA_POSSIVEL_OBITO_ENRIQUECIDO","ANO_POSSIVEL_OBITO_ENRIQUECIDO"],
    ["1","000123","Ana Ribeiro","15/04/1948","11111111111","","NÃO","11111111111","Ana Ribeiro","F","15/04/1948","NÃO","SIM","03/07/2026","","","","","","NÃO","",""],
    ["0","000124","Bruno Lima","22/08/1952","22222222222","","NÃO","22222222222","Bruno Lima","M","22/08/1952","NÃO","","","2024","","","","","NÃO","",""],
    ["1","000125","Carla Souza","10/01/1961","33333333333","","NÃO","33333333333","Carla Souza","F","10/01/1961","NÃO","NÃO","","","","","","","SIM","18/06/2026",""],
    ["2","000126","Daniel Rocha","04/06/1942","44444444444","","NÃO","44444444444","Daniel Rocha","M","04/06/1942","NÃO","NÃO","","","","","","","NÃO","","2023"],
    ["1","000127","Elisa Martins","27/11/1970","55555555555","","NÃO","55555555555","Elisa Martins","F","27/11/1970","NÃO","NÃO","","","","","","","NÃO","",""],
    ["2","000128","Fabio Nunes","19/03/1958","66666666666","","NÃO","66666666666","Fábio Nunes","M","19/03/1958","NÃO","X","45444","","","","","","NÃO","",""],
    ["1","999999","Registro sem cadastro","01/01/1950","99999999999","","NÃO","99999999999","Registro sem cadastro","M","01/01/1950","NÃO","TRUE","01/07/2026","","","","","","NÃO","",""]];

  function $(selector, root) { return (root || document).querySelector(selector); }
  function $$(selector, root) { return [...(root || document).querySelectorAll(selector)]; }
  function loadSettings() {
    try { return { affirmativeValues: C.AFFIRMATIVE_VALUES, recentDays: C.RECENT_DAYS, maxAge: C.MAX_AGE, ...JSON.parse(localStorage.getItem("cvobitos_settings") || "{}") }; }
    catch { return { affirmativeValues: C.AFFIRMATIVE_VALUES, recentDays: C.RECENT_DAYS, maxAge: C.MAX_AGE }; }
  }
  function loadHistory() {
    try {
      const parsed = JSON.parse(localStorage.getItem("cvobitos_history") || "null");
      if (parsed?.apuracoes && parsed.versao_schema === C.HISTORY_SCHEMA) return parsed;
      if (parsed?.apuracoes?.length) legacyHistoryDetected = true;
      return { versao_schema: C.HISTORY_SCHEMA, apuracoes: [] };
    }
    catch { return { versao_schema: C.HISTORY_SCHEMA, apuracoes: [] }; }
  }
  function persist() {
    localStorage.setItem("cvobitos_settings", JSON.stringify(state.settings));
    localStorage.setItem("cvobitos_history", JSON.stringify(state.history));
  }
  function toast(message, type) {
    const el = $("#toast"); el.textContent = message; el.className = `toast show ${type || "info"}`;
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3500);
  }
  function formatDuration(milliseconds) {
    const totalSeconds = Math.max(0, Math.round(milliseconds / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }
  function refreshBusyClock() {
    const elapsed = performance.now() - busyState.startedAt;
    $("#busyElapsed").textContent = `${formatDuration(elapsed)} decorridos`;
    if (busyState.percent >= 2 && busyState.percent < 100) {
      const remaining = elapsed * (100 - busyState.percent) / busyState.percent;
      $("#busyEta").textContent = `~${formatDuration(remaining)} restantes`;
    } else if (busyState.percent >= 100) $("#busyEta").textContent = "Concluindo...";
    else $("#busyEta").textContent = "Calculando estimativa...";
  }
  function updateBusy(progress) {
    if ($("#busy").hidden) return;
    if (progress?.message || progress?.phase) $("#busyText").textContent = progress.message || progress.phase;
    if (progress?.detail) $("#busyDetail").textContent = progress.detail;
    if (Number.isFinite(Number(progress?.percent))) busyState.percent = Math.max(busyState.percent, Math.min(100, Number(progress.percent)));
    $("#busyPercent").textContent = `${Math.round(busyState.percent)}%`;
    $("#busyProgressBar").style.width = `${busyState.percent}%`;
    refreshBusyClock();
  }
  function setBusy(active, message, detail) {
    const busy = $("#busy");
    if (!active) {
      busy.hidden = true;
      clearInterval(busyState.timer); busyState.timer = null;
      return;
    }
    busyState.startedAt = performance.now(); busyState.percent = 0;
    busy.hidden = false;
    $("#busyText").textContent = message || "Processando...";
    $("#busyDetail").textContent = detail || "Preparando operação local.";
    $("#busyPercent").textContent = "0%"; $("#busyProgressBar").style.width = "0%";
    refreshBusyClock();
    clearInterval(busyState.timer);
    busyState.timer = setInterval(refreshBusyClock, 250);
  }
  function showView(id) {
    $$(".view").forEach((view) => view.classList.toggle("active", view.id === id));
    $$("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === id));
    $("#pageTitle").textContent = $(`[data-view="${id}"]`)?.dataset.title || "Central de Validação de Óbitos";
    if (id === "reports") Reports.render(state);
    window.scrollTo(0, 0);
  }
  function populateSheetSelect(kind) {
    const workbook = state[`${kind}Workbook`];
    const select = $(`#${kind}Sheet`); select.replaceChildren();
    Object.keys(workbook || {}).forEach((name) => select.append(new Option(name, name)));
    select.disabled = !Object.keys(workbook || {}).length;
  }
  async function analyze(kind, onProgress) {
    const workbook = state[`${kind}Workbook`]; if (!workbook) return;
    const sheet = $(`#${kind}Sheet`).value || Object.keys(workbook)[0];
    const file = state[`${kind}File`];
    state[`${kind}Validation`] = await Validation.analyzeAsync(kind === "base" ? "base" : "return", workbook[sheet], { filename: file?.name || `dados_demonstracao_${kind}.xlsx`, sheet, competence: state.competence }, onProgress);
    renderValidation();
  }
  function updateCompetenceWarnings() {
    ["base", "return"].forEach((kind) => {
      const validation = state[`${kind}Validation`];
      if (!validation) return;
      validation.competenceWarning = Validation.competenceWarning({ competence: state.competence, filename: validation.filename });
    });
    renderValidation();
  }
  async function analyzeSelectedSheet(kind) {
    if (!state[`${kind}Workbook`]) return;
    const label = kind === "base" ? "base cadastral completa" : "retorno do Bureau Externo";
    setBusy(true, `Validando ${label}...`, "Analisando a aba selecionada em blocos.");
    try {
      await analyze(kind, (progress) => updateBusy(progress));
      updateFileCard(kind);
      toast(`Aba do ${label} validada.`, "success");
    } catch (error) { toast(error.message || "Não foi possível validar a aba.", "error"); }
    finally { setBusy(false); }
  }
  async function handleFile(kind, file) {
    if (!file) return;
    const label = kind === "base" ? "base cadastral completa" : "retorno enriquecido do Bureau Externo";
    setBusy(true, `Carregando ${label}...`, file.name);
    try {
      const workbook = await CVXlsx.read(file, (progress) => updateBusy({ ...progress, percent: progress.percent * 0.72 }));
      state[`${kind}File`] = file; state[`${kind}Workbook`] = workbook;
      populateSheetSelect(kind);
      await analyze(kind, (progress) => updateBusy({ ...progress, percent: 72 + progress.percent * 0.28 }));
      updateFileCard(kind);
      updateBusy({ percent: 100, message: `${label} carregado`, detail: `${state[`${kind}Validation`].rowCount} linhas validadas` });
      toast(`${file.name} carregado e validado.`, "success");
    } catch (error) { toast(error.message || "Não foi possível ler o arquivo.", "error"); }
    finally { setBusy(false); }
  }
  function updateFileCard(kind) {
    const file = state[`${kind}File`], validation = state[`${kind}Validation`];
    $(`#${kind}FileName`).textContent = file?.name || (state[`${kind}Workbook`] ? "Dados de demonstração" : "Nenhum arquivo selecionado");
    const badge = $(`#${kind}Status`);
    badge.textContent = validation ? (validation.blocking ? "Bloqueado" : "Validado") : "Aguardando";
    badge.className = `status-badge ${validation ? (validation.blocking ? "danger" : "success") : "neutral"}`;
  }
  function validationCard(validation, label) {
    if (!validation) return `<article class="validation-card empty"><h3>${label}</h3><p>Carregue o arquivo para executar as verificações.</p></article>`;
    const issues = validation.missingEssential.length + validation.emptyKeys.length + validation.invalidDates.length + validation.invalidIds.length + validation.duplicates.length;
    return `<article class="validation-card ${validation.blocking ? "blocked" : "ready"}"><div class="validation-head"><div><span>${label}</span><h3>${U.escapeHtml(validation.filename)}</h3></div><span class="quality-score">${validation.blocking ? "Bloqueado" : issues ? "Com alertas" : "Aprovado"}</span></div><dl class="mini-metrics"><div><dt>Linhas</dt><dd>${validation.rowCount}</dd></div><div><dt>Colunas</dt><dd>${validation.columnCount}</dd></div><div><dt>Reconhecidas</dt><dd>${validation.recognized.length}</dd></div><div><dt>Duplicidades</dt><dd>${validation.duplicates.length}</dd></div></dl><div class="issue-list">${validation.missingEssential.length ? `<p class="error"><strong>Obrigatórias ausentes:</strong> ${validation.missingEssential.join(", ")}</p>` : ""}${validation.missingOptional.length ? `<p><strong>Opcionais ausentes:</strong> ${validation.missingOptional.slice(0, 6).join(", ")}${validation.missingOptional.length > 6 ? "..." : ""}</p>` : ""}${validation.emptyKeys.length ? `<p class="error"><strong>Matrículas vazias:</strong> linhas ${validation.emptyKeys.slice(0, 6).join(", ")}</p>` : ""}${validation.invalidDates.length ? `<p><strong>Datas inválidas:</strong> ${validation.invalidDates.length} ocorrência(s)</p>` : ""}${validation.invalidIds.length ? `<p><strong>IDs inválidos:</strong> ${validation.invalidIds.length} ocorrência(s)</p>` : ""}${validation.competenceWarning ? `<p class="warning">${U.escapeHtml(validation.competenceWarning)}</p>` : ""}</div><footer>Aba: ${U.escapeHtml(validation.sheet)}</footer></article>`;
  }
  function renderValidation() {
    $("#validationGrid").innerHTML = validationCard(state.baseValidation, "Base Cadastral Completa") + validationCard(state.returnValidation, "Retorno Enriquecido do Bureau Externo");
    const comparison = Validation.compare(state.baseValidation, state.returnValidation);
    $("#matchPreview").innerHTML = state.baseValidation && state.returnValidation ? `<strong>${U.formatPercent(comparison.rate)}</strong><span>match preliminar · ${comparison.unmatched} retorno(s) sem cadastro</span>` : `<strong>-</strong><span>aguardando os dois arquivos</span>`;
    $("#processBtn").disabled = !(state.baseValidation && state.returnValidation) || state.baseValidation?.blocking || state.returnValidation?.blocking;
  }
  async function process() {
    if ($("#processBtn").disabled) return;
    setBusy(true, "Processando competência...", "Preparando cruzamento das matrículas.");
    try {
      state.competence = $("#competence").value;
      state.records = await Rules.processAsync(state.baseValidation.rows, state.returnValidation.rows, { ...state.settings, competence: state.competence }, (progress) => updateBusy({ ...progress, percent: progress.percent * 0.58 }));
      state.summary = await Analytics.summarizeAsync(state.records, { base: state.baseValidation.rowCount, returned: state.returnValidation.rowCount }, (progress) => updateBusy({ ...progress, percent: 58 + progress.percent * 0.22 }));
      updateBusy({ percent: 82, message: "Calculando rastreabilidade", detail: "Gerando identificador local da base cadastral completa." });
      await U.yieldToMain();
      const baseHash = await U.sha256(state.baseFile);
      updateBusy({ percent: 87, message: "Calculando rastreabilidade", detail: "Gerando identificador local do retorno do Bureau Externo." });
      const returnHash = await U.sha256(state.returnFile);
      updateBusy({ percent: 92, message: "Atualizando histórico", detail: `Registrando a competência ${state.competence}.` });
      const entry = Analytics.historyEntry({ competence: state.competence, baseName: state.baseFile?.name || "demo_base.xlsx", returnName: state.returnFile?.name || "demo_retorno.xlsx", baseHash, returnHash, rulesVersion: C.RULES_VERSION }, state.summary);
      state.history = Analytics.upsertHistory(state.history, entry); persist();
      updateBusy({ percent: 96, message: "Montando telas e relatórios", detail: "Exibindo somente os primeiros 20 registros nas listas operacionais." });
      await U.yieldToMain();
      renderResults(); renderHistory(); renderExports(); Reports.render(state); showView("results");
      updateBusy({ percent: 100, message: "Processamento concluído", detail: `${state.records.length} registros consolidados.` });
      toast(`Competência ${state.competence} processada com sucesso.`, "success");
    } catch (error) { console.error(error); toast(error.message || "Falha no processamento.", "error"); }
    finally { setBusy(false); }
  }
  function metric(label, value, note, tone) { return `<article class="metric ${tone || ""}"><span>${label}</span><strong>${value}</strong><small>${note || ""}</small></article>`; }
  function renderResults() {
    if (!state.summary) return;
    const i = state.summary.indicators, d = state.summary.distributions;
    $("#resultPeriod").textContent = `Competência ${state.competence}`;
    $("#kpiGrid").innerHTML = metric("Processados", U.formatNumber(i.total_processados, 0), `${i.total_base} cadastrais · ${i.total_retorno} retornos`) + metric("Óbitos confirmados", U.formatNumber(i.obitos_confirmados, 0), U.formatPercent(i.taxa_obito_confirmado), "accent") + metric("Possíveis óbitos", U.formatNumber(i.obitos_possiveis, 0), "exigem análise", "warning") + metric("Óbitos confirmados · ID 1", U.formatNumber(i.novos_obitos_participantes_id1, 0), "participantes", "danger") + metric("Match cadastral", U.formatPercent(i.taxa_match_cadastral), `${i.retornos_sem_cadastro} sem cadastro`, "blue") + metric("Inconsistências", U.formatNumber(i.inconsistencias, 0), "apontamentos de qualidade");
    $("#classChart").innerHTML = Charts.bar(d.classificacao, { label: "Classificação de óbito" });
    $("#idChart").innerHTML = Charts.bar(d.id, { label: "Distribuição por ID" });
    $("#ufChart").innerHTML = Charts.bar(d.uf, { label: "Distribuição por UF", limit: 10 });
    renderTable(); renderIssues();
  }
  function filteredRecords(limit) {
    return Table.select(state.records, {
      search: $("#tableSearch")?.value || "",
      classification: $("#filterClassification")?.value || "",
      id: $("#filterId")?.value || "",
      deathPrecision: $("#filterDeathPrecision")?.value || "",
      limit: limit || TABLE_LIMIT
    });
  }
  function displayDeathDate(row) {
    return row.dataObito ? U.formatDate(row.dataObito) : row.anoObito || "-";
  }
  function renderTable() {
    const result = filteredRecords(TABLE_LIMIT);
    const shown = result.rows.length;
    $("#tableCount").textContent = `${U.formatNumber(result.total, 0)} registro(s)`;
    $("#tableLimitNote").innerHTML = result.total
      ? `Exibindo <strong>${shown}</strong> de <strong>${U.formatNumber(result.total, 0)}</strong> registro(s) encontrado(s).${result.exactName ? " Correspondência exata de nome aplicada." : ""}`
      : "Nenhum registro corresponde aos filtros atuais.";
    $("#exportFilteredIdBtn").disabled = !state.summary || !$("#filterId").value;
    $("#resultTableBody").innerHTML = result.rows.map((row) => `<tr data-record="${row.__index}"><td><strong>${U.escapeHtml(row.matricula)}</strong><small>${U.escapeHtml(row.nome)}</small></td><td><span class="pill id">ID ${U.escapeHtml(row.id || "-")}</span><small>${U.escapeHtml(row.perfilId)}</small></td><td><span class="pill ${row.classificacao === "Confirmado" ? "confirmed" : row.classificacao === "Possível" ? "possible" : "clear"}">${row.classificacao}</span></td><td>${U.escapeHtml(displayDeathDate(row))}<small>${U.escapeHtml(row.precisaoDataObito)}</small></td><td>${row.idadeObito ?? "-"}</td><td>${U.escapeHtml(row.plano)}</td><td>${U.escapeHtml(row.uf)}</td><td><span class="pill ${row.inconsistencias.length ? "issue" : "ok"}">${row.inconsistencias.length ? `${row.inconsistencias.length} alerta(s)` : "Consistente"}</span></td></tr>`).join("");
  }
  function renderIssues() {
    const issues = []; let total = 0;
    state.records.forEach((row) => { if (row.inconsistencias.length) { total += 1; if (issues.length < TABLE_LIMIT) issues.push(row); } });
    $("#issueCount").textContent = `${U.formatNumber(total, 0)} registro(s)`;
    $("#issueList").innerHTML = issues.length ? `${issues.map((row) => `<article class="issue-item"><div><strong>${U.escapeHtml(row.matricula)} · ${U.escapeHtml(row.nome)}</strong><span>${U.escapeHtml(row.inconsistencias.join(" · "))}</span></div><button class="text-button" data-open-record="${row.__index}">Ver registro</button></article>`).join("")}${total > TABLE_LIMIT ? `<div class="list-limit">Exibindo os 20 primeiros de ${U.formatNumber(total, 0)} registros com inconsistência.</div>` : ""}` : `<div class="empty-state">Nenhuma inconsistência identificada.</div>`;
    $("#exportIssuesBtn").disabled = !state.summary || total === 0;
  }
  function openRecord(index) {
    const row = state.records[Number(index)]; if (!row) return;
    $("#recordModalBody").innerHTML = `<div class="record-hero"><div><span>Matrícula Petros</span><h2>${U.escapeHtml(row.matricula)}</h2><p>${U.escapeHtml(row.nome)}</p></div><span class="pill ${row.classificacao === "Confirmado" ? "confirmed" : row.classificacao === "Possível" ? "possible" : "clear"}">${row.classificacao}</span></div><dl class="record-grid">${[["ID", row.id],["Perfil do ID", row.perfilId],["CPF", row.cpf],["Match", row.matchStatus],["Data de nascimento", row.dataNascimento ? U.formatDate(row.dataNascimento) : "-"],["Data de óbito", displayDeathDate(row)],["Precisão", row.precisaoDataObito],["Idade de óbito", row.idadeObito ?? "-"],["Plano", row.plano],["Patrocinadora", row.patrocinadora],["Situação", row.situacao],["UF", row.uf],["Evidências", row.evidencias],["Inconsistências", row.inconsistencias.join("; ") || "Nenhuma"]].map(([label, value]) => `<div><dt>${label}</dt><dd>${U.escapeHtml(value)}</dd></div>`).join("")}</dl>`;
    $("#recordModal").showModal();
  }
  function renderHistory() {
    const history = state.history.apuracoes || [];
    $("#historySeries").innerHTML = Charts.line(history, "total_processados", { label: "Evolução de dados processados" });
    $("#historyDeaths").innerHTML = Charts.line(history, "obitos_confirmados", { label: "Evolução de óbitos confirmados", color: "#de8e28" });
    $("#historyTableBody").innerHTML = history.map((item) => `<tr><td><strong>${U.escapeHtml(item.competencia)}</strong></td><td>${U.formatNumber(item.indicadores?.total_processados, 0)}</td><td>${U.formatNumber(item.indicadores?.obitos_confirmados, 0)}</td><td>${U.formatNumber(item.indicadores?.obitos_possiveis, 0)}</td><td>${U.formatNumber(item.indicadores?.novos_obitos_participantes_id1, 0)}</td><td>${U.formatPercent(item.indicadores?.taxa_match_cadastral)}</td><td>${U.formatNumber(item.indicadores?.inconsistencias, 0)}</td></tr>`).join("");
    $("#historyEmpty").hidden = history.length > 0;
  }
  function renderExports() {
    $$("[data-requires-results]").forEach((button) => { button.disabled = !state.summary; });
    $("#exportFilteredIdBtn").disabled = !state.summary || !$("#filterId").value;
    $("#exportIssuesBtn").disabled = !state.summary || !state.records.some((row) => row.inconsistencias.length);
  }
  async function importHistory(file) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (parsed.versao_schema !== C.HISTORY_SCHEMA || !Array.isArray(parsed.apuracoes)) throw new Error(`Histórico incompatível: esperado schema ${C.HISTORY_SCHEMA}. Reprocesse competências calculadas com a regra antiga de IDs.`);
      state.history = parsed; persist(); renderHistory(); Reports.render(state); toast(`${parsed.apuracoes.length} competência(s) importada(s).`, "success");
    } catch (error) { toast(error.message || "Histórico inválido.", "error"); }
  }
  async function loadDemo() {
    state.baseFile = null; state.returnFile = null;
    state.baseWorkbook = { Base_Cadastral: demoBase }; state.returnWorkbook = { Retorno_Ph3a: demoReturn };
    populateSheetSelect("base"); populateSheetSelect("return"); await analyze("base"); await analyze("return"); updateFileCard("base"); updateFileCard("return");
    toast("Dados de demonstração carregados. Revise a validação e processe.", "success");
  }
  function bindEvents() {
    $$("[data-view]").forEach((button) => button.addEventListener("click", () => showView(button.dataset.view)));
    $("#competence").value = state.competence; $("#competence").addEventListener("change", (event) => { state.competence = event.target.value; updateCompetenceWarnings(); });
    $("#baseFile").addEventListener("change", (event) => handleFile("base", event.target.files[0]));
    $("#returnFile").addEventListener("change", (event) => handleFile("return", event.target.files[0]));
    $("#baseSheet").addEventListener("change", () => analyzeSelectedSheet("base")); $("#returnSheet").addEventListener("change", () => analyzeSelectedSheet("return"));
    $("#processBtn").addEventListener("click", process);
    $("#tableSearch").addEventListener("input", () => { clearTimeout(tableRenderTimer); tableRenderTimer = setTimeout(renderTable, 180); });
    $("#filterClassification").addEventListener("change", renderTable);
    $("#filterId").addEventListener("change", renderTable);
    $("#filterDeathPrecision").addEventListener("change", renderTable);
    $("#exportFilteredIdBtn").addEventListener("click", async () => {
      const id = $("#filterId").value; if (!id || !state.summary) return;
      setBusy(true, `Gerando relatório do ID ${id}...`, `Incluindo todos os registros de ${C.ID_PROFILES[id]}.`);
      try {
        await Exports.workbook(state.records, state.summary, state.competence, "ID", { id });
        updateBusy({ percent: 100, message: "Relatório Excel concluído", detail: `ID ${id} · ${C.ID_PROFILES[id]}` });
        toast(`Relatório do ID ${id} gerado com todos os registros correspondentes.`, "success");
      } catch (error) { toast(error.message || "Falha ao gerar o relatório do ID.", "error"); }
      finally { setBusy(false); }
    });
    $("#resultTableBody").addEventListener("click", (event) => { const row = event.target.closest("tr[data-record]"); if (row) openRecord(row.dataset.record); });
    $("#issueList").addEventListener("click", (event) => { const button = event.target.closest("[data-open-record]"); if (button) openRecord(button.dataset.openRecord); });
    $("#toggleIssuesBtn").addEventListener("click", () => { const panel = $("#issueList"), expanded = panel.hidden; panel.hidden = !expanded; $("#toggleIssuesBtn").textContent = expanded ? "Ocultar inconsistências" : "Exibir inconsistências"; $("#toggleIssuesBtn").setAttribute("aria-expanded", String(expanded)); });
    $("#exportIssuesBtn").addEventListener("click", async () => { if (!state.summary) return; setBusy(true, "Gerando inconsistências...", "Preparando todos os registros para análise no Excel."); try { await Exports.workbook(state.records, state.summary, state.competence, "INCONSISTENCIAS"); toast("Arquivo de inconsistências gerado.", "success"); } catch (error) { toast(error.message || "Falha ao gerar inconsistências.", "error"); } finally { setBusy(false); } });
    $("#closeRecordModal").addEventListener("click", () => $("#recordModal").close());
    $("#historyFile").addEventListener("change", (event) => importHistory(event.target.files[0]));
    $("#exportHistoryBtn").addEventListener("click", () => Exports.history(state.history));
    $$("[data-export]").forEach((button) => button.addEventListener("click", async () => { setBusy(true, "Gerando arquivo Excel..."); try { await Exports.workbook(state.records, state.summary, state.competence, button.dataset.export); toast("Exportação gerada.", "success"); } catch (error) { toast(error.message, "error"); } finally { setBusy(false); } }));
    $("#packageBtn").addEventListener("click", async () => { setBusy(true, "Montando pacote de apuração..."); try { await Exports.packageZip(state); toast("Pacote ZIP gerado.", "success"); } catch (error) { toast(error.message, "error"); } finally { setBusy(false); } });
    $$("[data-print]").forEach((button) => button.addEventListener("click", () => Reports.print(button.dataset.print)));
    $("#settingsForm").addEventListener("submit", (event) => { event.preventDefault(); state.settings = { affirmativeValues: $("#affirmativeValues").value.split(",").map((value) => value.trim()).filter(Boolean), recentDays: Number($("#recentDays").value) || C.RECENT_DAYS, maxAge: Number($("#maxAge").value) || C.MAX_AGE }; persist(); toast("Configurações salvas localmente.", "success"); });
  }
  function initializeSettings() { $("#affirmativeValues").value = state.settings.affirmativeValues.join(", "); $("#recentDays").value = state.settings.recentDays; $("#maxAge").value = state.settings.maxAge; }
  function init() {
    bindEvents(); initializeSettings(); renderValidation(); renderHistory(); renderExports(); Reports.render(state); showView("processing");
    if (legacyHistoryDetected) {
      persist();
      toast("O histórico da regra antiga foi desconsiderado. Reprocesse as competências com os IDs 0, 1 e 2.", "error");
    }
  }
  document.addEventListener("DOMContentLoaded", init);
})();
