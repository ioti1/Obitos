(function (root, factory) {
  const deps = typeof module === "object" && module.exports
    ? { config: require("./config.js"), utils: require("./utils.js") }
    : { config: root.CVConfig, utils: root.CVUtils };
  const api = factory(deps.config, deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVValidation = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (Config, U) {
  "use strict";

  function duplicateValues(objects, field) {
    const counts = new Map();
    objects.forEach((row) => {
      const value = U.normalizeMatricula(row[field]);
      if (value) counts.set(value, (counts.get(value) || 0) + 1);
    });
    return [...counts.entries()].filter(([, count]) => count > 1).map(([value, count]) => ({ value, count }));
  }

  function invalidDates(objects, fields) {
    const issues = [];
    objects.forEach((row) => fields.forEach((field) => {
      const value = row[field];
      if (!U.isBlank(value) && !U.parseDate(value) && !U.isValidYear(value)) issues.push({ row: row.__row, field, value });
    }));
    return issues;
  }

  function competenceWarning(meta) {
    const competence = String(meta?.competence || "");
    const filename = String(meta?.filename || "");
    return competence && /\d{4}[-_]\d{2}/.test(filename) && !filename.replace("_", "-").includes(competence)
      ? `O nome do arquivo pode indicar competência diferente de ${competence}.` : "";
  }

  function analyze(kind, rows, meta) {
    const aliases = kind === "base" ? Config.BASE_COLUMNS : Config.RETURN_COLUMNS;
    const essentials = kind === "base" ? Config.ESSENTIAL_BASE : Config.ESSENTIAL_RETURN;
    const headers = rows[0] || [];
    const mapping = U.mapHeaders(headers, aliases);
    if (kind === "return" && headers.length) mapping.id = 0;
    const objects = U.rowsToObjects(rows, mapping);
    const missingEssential = essentials.filter((key) => mapping[key] == null);
    const missingOptional = Object.keys(aliases).filter((key) => mapping[key] == null && !essentials.includes(key));
    const duplicates = duplicateValues(objects, "matricula");
    const emptyKeys = objects.filter((row) => U.isBlank(row.matricula)).map((row) => row.__row);
    const dateFields = kind === "base"
      ? ["dataNascimento", "dataObitoCadastral"]
      : ["dataNascimento", "dataNascEnriquecido", "dataObito", "dataObitoEnriquecido", "dataPossivelObitoEnriquecido", "dataInicioExercicio", "dataFimCarreira"];
    const badDates = invalidDates(objects, dateFields.filter((field) => mapping[field] != null));
    const invalidIds = kind === "return" ? objects.filter((row) => !U.isBlank(row.id) && !["0", "1", "2"].includes(String(row.id).trim())).map((row) => ({ row: row.__row, value: row.id })) : [];
    return {
      kind,
      filename: String(meta?.filename || "") || "Arquivo sem nome",
      sheet: meta?.sheet || "Primeira aba",
      rowCount: objects.length,
      columnCount: headers.length,
      recognized: Object.keys(mapping),
      missingEssential,
      missingOptional,
      duplicates,
      emptyKeys,
      invalidDates: badDates,
      invalidIds,
      competenceWarning: competenceWarning(meta),
      blocking: missingEssential.length > 0 || emptyKeys.length === objects.length || objects.length === 0,
      rows: objects
    };
  }

  async function analyzeAsync(kind, rows, meta, onProgress) {
    const aliases = kind === "base" ? Config.BASE_COLUMNS : Config.RETURN_COLUMNS;
    const essentials = kind === "base" ? Config.ESSENTIAL_BASE : Config.ESSENTIAL_RETURN;
    const headers = rows[0] || [];
    const mapping = U.mapHeaders(headers, aliases);
    if (kind === "return" && headers.length) mapping.id = 0;
    const missingEssential = essentials.filter((key) => mapping[key] == null);
    const missingOptional = Object.keys(aliases).filter((key) => mapping[key] == null && !essentials.includes(key));
    const dateFields = (kind === "base"
      ? ["dataNascimento", "dataObitoCadastral"]
      : ["dataNascimento", "dataNascEnriquecido", "dataObito", "dataObitoEnriquecido", "dataPossivelObitoEnriquecido", "dataInicioExercicio", "dataFimCarreira"])
      .filter((field) => mapping[field] != null);
    const objects = [];
    const counts = new Map();
    const emptyKeys = [];
    const badDates = [];
    const invalidIds = [];
    const mappedEntries = Object.entries(mapping);
    const total = Math.max(rows.length - 1, 1);
    const chunk = 2500;

    onProgress?.({ percent: 0, phase: "Validando estrutura", detail: `${headers.length} colunas encontradas` });
    for (let sourceIndex = 1; sourceIndex < rows.length; sourceIndex += 1) {
      const source = rows[sourceIndex] || [];
      if (!source.some((value) => !U.isBlank(value))) continue;
      const object = { __row: sourceIndex + 1 };
      mappedEntries.forEach(([key, column]) => { object[key] = source[column] ?? ""; });
      objects.push(object);

      const key = U.normalizeMatricula(object.matricula);
      if (key) counts.set(key, (counts.get(key) || 0) + 1);
      else emptyKeys.push(object.__row);
      dateFields.forEach((field) => {
        const value = object[field];
        if (!U.isBlank(value) && !U.parseDate(value) && !U.isValidYear(value)) badDates.push({ row: object.__row, field, value });
      });
      if (kind === "return" && !U.isBlank(object.id) && !["0", "1", "2"].includes(String(object.id).trim())) {
        invalidIds.push({ row: object.__row, value: object.id });
      }

      if (sourceIndex % chunk === 0) {
        onProgress?.({ percent: Math.min(96, 5 + 91 * sourceIndex / total), phase: "Validando linhas", detail: `${sourceIndex - 1} de ${total} linhas analisadas` });
        await U.yieldToMain();
      }
    }

    const duplicates = [...counts.entries()].filter(([, count]) => count > 1).map(([value, count]) => ({ value, count }));
    const result = {
      kind,
      filename: String(meta?.filename || "") || "Arquivo sem nome",
      sheet: meta?.sheet || "Primeira aba",
      rowCount: objects.length,
      columnCount: headers.length,
      recognized: Object.keys(mapping),
      missingEssential,
      missingOptional,
      duplicates,
      emptyKeys,
      invalidDates: badDates,
      invalidIds,
      competenceWarning: competenceWarning(meta),
      blocking: missingEssential.length > 0 || emptyKeys.length === objects.length || objects.length === 0,
      rows: objects
    };
    onProgress?.({ percent: 100, phase: "Validação concluída", detail: `${objects.length} linhas válidas para processamento` });
    return result;
  }

  function compare(baseValidation, returnValidation) {
    if (!baseValidation?.rows || !returnValidation?.rows) return { match: 0, unmatched: 0, rate: 0, samples: [] };
    const baseKeys = new Set(baseValidation.rows.map((row) => U.normalizeMatricula(row.matricula)).filter(Boolean));
    const unmatchedRows = returnValidation.rows.filter((row) => !baseKeys.has(U.normalizeMatricula(row.matricula)));
    const total = returnValidation.rows.length;
    return { match: total - unmatchedRows.length, unmatched: unmatchedRows.length, rate: total ? (total - unmatchedRows.length) / total : 0, samples: unmatchedRows.slice(0, 5).map((row) => row.matricula) };
  }

  return { duplicateValues, invalidDates, competenceWarning, analyze, analyzeAsync, compare };
});
