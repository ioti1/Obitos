(function (root, factory) {
  const api = factory(root.CVUtils, root.CVCharts, root.CVConfig);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVReports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U, Charts, Config) {
  "use strict";
  function kpi(label, value, note) { return `<article class="report-kpi"><span>${U.escapeHtml(label)}</span><strong>${value}</strong><small>${U.escapeHtml(note || "")}</small></article>`; }
  function brand() { return `<div class="report-brand"><img src="assets/logo-petros.png?v=20260712-logo-oficial" alt="Petros"><span>Cadastro · Inteligência Cadastral</span></div>`; }
  function empty(message) { return `<div class="report-placeholder">${U.escapeHtml(message)}</div>`; }
  function monthly(state) {
    if (!state.summary) return empty("Processe uma competência para gerar o relatório mensal.");
    const i = state.summary.indicators, d = state.summary.distributions;
    const findings = [];
    findings.push(`${U.formatNumber(i.obitos_confirmados, 0)} óbitos confirmados e ${U.formatNumber(i.obitos_possiveis, 0)} possíveis no universo processado.`);
    findings.push(`Taxa de correspondência cadastral de ${U.formatPercent(i.taxa_match_cadastral)}.`);
    if (i.retornos_sem_cadastro) findings.push(`${i.retornos_sem_cadastro} retornos exigem análise por ausência de correspondência cadastral.`);
    if (i.inconsistencias) findings.push(`${i.inconsistencias} apontamentos de qualidade foram registrados.`);
    return `<article class="report-document" id="monthlyReport">
      <section class="report-cover">${brand()}<div class="report-cover-copy"><p class="eyebrow">Relatório executivo mensal</p><h1>Central de Validação de Óbitos</h1><h2>Competência ${U.escapeHtml(state.competence)}</h2><p>${Config.INTERNAL_NOTICE}</p></div><div class="report-cover-summary">${kpi("Registros processados", U.formatNumber(i.total_processados, 0))}${kpi("Óbitos confirmados", U.formatNumber(i.obitos_confirmados, 0))}${kpi("Possíveis óbitos", U.formatNumber(i.obitos_possiveis, 0))}${kpi("Óbitos confirmados · ID 1", U.formatNumber(i.novos_obitos_participantes_id1, 0))}${kpi("Match cadastral", U.formatPercent(i.taxa_match_cadastral))}</div><footer>Gerado em ${U.formatDate(new Date())} · Regras ${Config.RULES_VERSION}</footer></section>
      <section class="report-page"><header>${brand()}<span>${U.escapeHtml(state.competence)}</span></header><h2>Visão geral do processamento</h2><div class="report-overview"><p><strong>Arquivos utilizados:</strong> ${U.escapeHtml(state.baseFile?.name || "Não informado")} e ${U.escapeHtml(state.returnFile?.name || "Não informado")}.</p><p><strong>Universo:</strong> ${i.total_base} registros cadastrais e ${i.total_retorno} retornos do Bureau Externo.</p></div><div class="report-summary">${kpi("Confirmados", i.obitos_confirmados, "qualquer evidência confirmatória")}${kpi("Possíveis", i.obitos_possiveis, "sem evidência confirmatória")}${kpi("Sem óbito", i.sem_obito, "nenhuma regra acionada")}${kpi("Óbitos recentes", i.obitos_recentes, "janela configurada")}</div><div class="report-grid"><section><h3>Classificação</h3>${Charts.bar(d.classificacao, { limit: 6 })}</section><section><h3>Distribuição por ID</h3>${Charts.bar(d.id, { limit: 6 })}</section></div></section>
      <section class="report-page"><header>${brand()}<span>Análise e qualidade</span></header><h2>Achados da competência</h2><ul class="report-findings">${findings.map((item) => `<li>${U.escapeHtml(item)}</li>`).join("")}</ul><div class="report-grid"><section><h3>Planos com maior volume</h3>${Charts.bar(d.plano, { limit: 7 })}</section><section><h3>Distribuição por UF</h3>${Charts.bar(d.uf, { limit: 7 })}</section></div><div class="method-note"><strong>Nota metodológica.</strong> O cruzamento usa Matrícula Petros como texto e os perfis ID 0 (participantes), ID 1 (participantes com óbito conhecido sem data completa) e ID 2 (dependentes). A classificação de óbito usa flag, data válida ou ano; a idade usa a data completa ou, para ano coincidente com a competência, o primeiro dia do mês processado.</div><footer class="report-end">PETROS · Cadastro / Inteligência Cadastral · Uso interno</footer></section>
    </article>`;
  }
  function historical(state) {
    const history = state.history?.apuracoes || [];
    if (!history.length) return empty("Processe ou importe histórico para gerar o relatório comparativo.");
    const first = history[0], last = history[history.length - 1];
    const total = history.reduce((sum, item) => sum + Number(item.indicadores?.total_processados || 0), 0);
    const lastI = last.indicadores || {};
    return `<article class="report-document" id="historicalReport">
      <section class="report-cover">${brand()}<div class="report-cover-copy"><p class="eyebrow">Relatório executivo histórico</p><h1>Evolução da Validação de Óbitos</h1><h2>${U.escapeHtml(first.competencia)} a ${U.escapeHtml(last.competencia)}</h2><p>${Config.INTERNAL_NOTICE}</p></div><div class="report-cover-summary">${kpi("Competências", history.length)}${kpi("Total processado", U.formatNumber(total, 0))}${kpi("Confirmados no último mês", U.formatNumber(lastI.obitos_confirmados, 0))}${kpi("Possíveis no último mês", U.formatNumber(lastI.obitos_possiveis, 0))}${kpi("Match atual", U.formatPercent(lastI.taxa_match_cadastral))}</div><footer>Gerado em ${U.formatDate(new Date())} · Regras ${Config.RULES_VERSION}</footer></section>
      <section class="report-page"><header>${brand()}<span>Série histórica</span></header><h2>Evolução dos principais indicadores</h2><h3>Dados processados</h3>${Charts.line(history, "total_processados", { label: "Dados processados" })}<h3>Óbitos confirmados</h3>${Charts.line(history, "obitos_confirmados", { label: "Óbitos confirmados", color: "#de8e28" })}</section>
      <section class="report-page"><header>${brand()}<span>Monitoramento gerencial</span></header><h2>Tendências e recomendações</h2><div class="report-summary">${kpi("Óbitos confirmados · ID 1", U.formatNumber(lastI.novos_obitos_participantes_id1, 0), "última competência")}${kpi("Retornos sem cadastro", U.formatNumber(lastI.retornos_sem_cadastro, 0), "última competência")}${kpi("Inconsistências", U.formatNumber(lastI.inconsistencias, 0), "última competência")}${kpi("Idade média", lastI.idade_media_obito == null ? "-" : `${U.formatNumber(lastI.idade_media_obito, 1)} anos`, "datas completas")}</div><ul class="report-findings"><li>Monitorar variações abruptas de óbitos confirmados e possíveis entre competências.</li><li>Priorizar análise dos participantes ID 1 confirmados e retornos sem correspondência cadastral.</li><li>Revisar recortes por plano, patrocinadora e UF sempre que houver mudança relevante de volume.</li><li>Preservar o histórico exportado ao final de cada apuração para garantir continuidade da série.</li></ul><div class="method-note"><strong>Nota metodológica.</strong> A série usa uma observação agregada por competência. Reprocessar a mesma competência substitui o registro anterior para evitar dupla contagem.</div><footer class="report-end">PETROS · Cadastro / Inteligência Cadastral · Uso interno</footer></section>
    </article>`;
  }
  function render(state) {
    const monthlyRoot = document.getElementById("reportMonthlyRoot");
    const historicalRoot = document.getElementById("reportHistoricalRoot");
    if (monthlyRoot) monthlyRoot.innerHTML = monthly(state);
    if (historicalRoot) historicalRoot.innerHTML = historical(state);
  }
  function print(report) {
    document.body.dataset.printReport = report;
    window.print();
    setTimeout(() => delete document.body.dataset.printReport, 250);
  }
  return { monthly, historical, render, print };
});
