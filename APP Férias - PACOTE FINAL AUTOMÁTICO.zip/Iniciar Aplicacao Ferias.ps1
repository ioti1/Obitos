param(
  [switch]$NoBrowser,
  [string]$BasePathOverride = ""
)

$ErrorActionPreference = "Stop"

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $AppDir "config_base.txt"
$PortFile = Join-Path $AppDir ".calendario-ferias.port"
$AppFile = Join-Path $AppDir "Aplicação Férias.html"
if (!(Test-Path -LiteralPath $AppFile -PathType Leaf)) {
  $AppFile = (Get-ChildItem -LiteralPath $AppDir -File -Filter "*.html" |
    Sort-Object Length -Descending |
    Select-Object -First 1).FullName
}
$DefaultBasePath = "F:\DADOS\CADASTRO\N$([char]0x00DA)CLEO ANALYTICS\Sistema Interno Cadastro\calendario-ferias"
$DefaultFileName = "Calendario_Ferias_Setor.xlsx"
$Script:BasePath = $DefaultBasePath
$Script:BaseFileName = $DefaultFileName

function Read-AppConfig {
  $basePath = $DefaultBasePath
  $fileName = $DefaultFileName

  if (Test-Path -LiteralPath $ConfigFile) {
    $raw = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8
    $pathMatch = [regex]::Match($raw, 'caminhoPastaOficial\s*:\s*String\.raw`([^`]*)`')
    if ($pathMatch.Success -and $pathMatch.Groups[1].Value.Trim()) {
      $basePath = $pathMatch.Groups[1].Value.Trim()
    }

    $fileMatch = [regex]::Match($raw, 'nomeArquivoBase\s*:\s*["'']([^"'']+)["'']')
    if ($fileMatch.Success -and $fileMatch.Groups[1].Value.Trim()) {
      $fileName = $fileMatch.Groups[1].Value.Trim()
    }
  }

  if (![string]::IsNullOrWhiteSpace($BasePathOverride)) {
    $basePath = $BasePathOverride
  }

  $Script:BasePath = $basePath.TrimEnd("\", "/")
  $Script:BaseFileName = $fileName
}

function Send-Bytes($Context, [byte[]]$Bytes, [string]$ContentType, [int]$StatusCode = 200) {
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.ContentType = $ContentType
  $Context.Response.ContentLength64 = $Bytes.Length
  $Context.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
  $Context.Response.OutputStream.Close()
}

function Send-Text($Context, [string]$Text, [string]$ContentType = "text/plain; charset=utf-8", [int]$StatusCode = 200) {
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
  Send-Bytes $Context $bytes $ContentType $StatusCode
}

function Send-Json($Context, $Data, [int]$StatusCode = 200) {
  $json = $Data | ConvertTo-Json -Depth 8
  Send-Text $Context $json "application/json; charset=utf-8" $StatusCode
}

function Send-ErrorJson($Context, [string]$Message, [int]$StatusCode = 500) {
  Send-Json $Context @{ ok = $false; error = $Message } $StatusCode
}

function Get-SafeTargetPath([string]$RelativeName) {
  if ([string]::IsNullOrWhiteSpace($RelativeName)) {
    throw "Nome de arquivo ausente."
  }
  if ([System.IO.Path]::IsPathRooted($RelativeName)) {
    throw "Caminho absoluto nao e permitido nessa chamada."
  }

  $relative = $RelativeName.Replace("/", "\").TrimStart("\")
  $baseFull = [System.IO.Path]::GetFullPath($Script:BasePath)
  $targetFull = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($baseFull, $relative))
  $basePrefix = $baseFull.TrimEnd("\") + "\"

  if (!$targetFull.StartsWith($basePrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Caminho fora da pasta configurada."
  }

  return $targetFull
}

function Get-ContentType([string]$Path) {
  $extension = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
  switch ($extension) {
    ".html" { "text/html; charset=utf-8" }
    ".txt" { "application/javascript; charset=utf-8" }
    ".js" { "application/javascript; charset=utf-8" }
    ".json" { "application/json; charset=utf-8" }
    ".xlsx" { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }
    default { "application/octet-stream" }
  }
}

function Read-RequestBytes($Context) {
  $memory = New-Object System.IO.MemoryStream
  $Context.Request.InputStream.CopyTo($memory)
  return $memory.ToArray()
}

function Handle-Request($Context) {
  Read-AppConfig
  $path = $Context.Request.Url.AbsolutePath

  try {
    if ($path -eq "/" -or $path -eq "/index.html") {
      if (!(Test-Path -LiteralPath $AppFile)) {
        Send-ErrorJson $Context "Arquivo da aplicacao nao encontrado." 404
        return
      }
      Send-Bytes $Context ([System.IO.File]::ReadAllBytes($AppFile)) "text/html; charset=utf-8"
      return
    }

    if ($path -eq "/config_base.txt") {
      if (!(Test-Path -LiteralPath $ConfigFile)) {
        Send-ErrorJson $Context "Arquivo config_base.txt nao encontrado." 404
        return
      }
      Send-Bytes $Context ([System.IO.File]::ReadAllBytes($ConfigFile)) "application/javascript; charset=utf-8"
      return
    }

    if ($path -eq "/api/ping") {
      $baseExists = Test-Path -LiteralPath $Script:BasePath -PathType Container
      $filePath = [System.IO.Path]::Combine($Script:BasePath, $Script:BaseFileName)
      Send-Json $Context @{
        ok = $true
        appId = "calendario-ferias"
        enabled = $true
        basePath = $Script:BasePath
        fileName = $Script:BaseFileName
        folderName = Split-Path -Leaf $Script:BasePath
        baseExists = $baseExists
        fileExists = (Test-Path -LiteralPath $filePath -PathType Leaf)
      }
      return
    }

    if ($path -eq "/api/exists") {
      $name = $Context.Request.QueryString["name"]
      $target = Get-SafeTargetPath $name
      Send-Json $Context @{ ok = $true; exists = (Test-Path -LiteralPath $target -PathType Leaf) }
      return
    }

    if ($path -eq "/api/mkdir") {
      if ($Context.Request.HttpMethod -ne "POST") {
        Send-ErrorJson $Context "Metodo nao permitido." 405
        return
      }
      $name = $Context.Request.QueryString["name"]
      $target = Get-SafeTargetPath $name
      New-Item -ItemType Directory -Path $target -Force | Out-Null
      Send-Json $Context @{ ok = $true }
      return
    }

    if ($path -eq "/api/read") {
      $name = $Context.Request.QueryString["name"]
      $target = Get-SafeTargetPath $name
      if (!(Test-Path -LiteralPath $target -PathType Leaf)) {
        Send-ErrorJson $Context "Arquivo nao encontrado: $name" 404
        return
      }
      Send-Bytes $Context ([System.IO.File]::ReadAllBytes($target)) (Get-ContentType $target)
      return
    }

    if ($path -eq "/api/write") {
      if ($Context.Request.HttpMethod -ne "POST") {
        Send-ErrorJson $Context "Metodo nao permitido." 405
        return
      }
      $name = $Context.Request.QueryString["name"]
      $target = Get-SafeTargetPath $name
      $parent = Split-Path -Parent $target
      if (!(Test-Path -LiteralPath $parent -PathType Container)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
      }
      [System.IO.File]::WriteAllBytes($target, (Read-RequestBytes $Context))
      Send-Json $Context @{ ok = $true }
      return
    }

    Send-ErrorJson $Context "Rota nao encontrada." 404
  } catch {
    Send-ErrorJson $Context $_.Exception.Message 500
  }
}

if (!$AppFile -or !(Test-Path -LiteralPath $AppFile)) {
  throw "Arquivo da aplicacao nao encontrado na pasta: $AppDir"
}

Read-AppConfig

if (Test-Path -LiteralPath $PortFile -PathType Leaf) {
  try {
    $existingPort = [int](Get-Content -LiteralPath $PortFile -Raw).Trim()
    $existing = Invoke-RestMethod -Uri "http://127.0.0.1:$existingPort/api/ping" -TimeoutSec 1
    if ($existing.appId -eq "calendario-ferias") {
      if (!$NoBrowser) {
        Start-Process "http://127.0.0.1:$existingPort/?localServer=1"
      }
      exit 0
    }
  } catch {
    Remove-Item -LiteralPath $PortFile -Force -ErrorAction SilentlyContinue
  }
}

$port = $null
$listener = $null
$startupErrors = @()
foreach ($candidate in 8787..8810) {
  $candidateListener = New-Object System.Net.HttpListener
  try {
    $candidateListener.Prefixes.Add("http://127.0.0.1:$candidate/")
    $candidateListener.Start()
    $listener = $candidateListener
    $port = $candidate
    break
  } catch {
    $startupErrors += "Porta ${candidate}: $($_.Exception.Message)"
    try {
      $candidateListener.Close()
    } catch {
    }
    continue
  }
}

if (!$port) {
  $detail = $startupErrors -join "`n"
  throw "Nao foi possivel iniciar o servidor local da aplicacao.`n$detail"
}

$url = "http://127.0.0.1:$port/?localServer=1"
Set-Content -LiteralPath $PortFile -Value $port -Encoding ASCII
Write-Host ""
Write-Host "Calendario de Ferias iniciado."
Write-Host "Caminho configurado: $Script:BasePath"
Write-Host "Arquivo esperado: $Script:BaseFileName"
Write-Host "Endereco local: $url"
Write-Host ""
Write-Host "Mantenha esta janela aberta enquanto estiver usando a aplicacao."
Write-Host "Pressione Ctrl+C para encerrar."
Write-Host ""

if (!$NoBrowser) {
  Start-Process $url
}

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    Handle-Request $context
  }
} finally {
  if ($listener.IsListening) {
    $listener.Stop()
  }
  $listener.Close()
  Remove-Item -LiteralPath $PortFile -Force -ErrorAction SilentlyContinue
}
