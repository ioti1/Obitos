const { readFileSync, readdirSync, statSync } = require("node:fs");
const { join, resolve, relative } = require("node:path");

const root = resolve(__dirname, "..");
const forbidden = [/\bfetch\s*\(/, /XMLHttpRequest/, /new\s+WebSocket/, /EventSource\s*\(/, /sendBeacon\s*\(/, /https?:\/\//i, /cdn\./i];
const failures = [];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    const file = join(dir, name); const stat = statSync(file);
    if (stat.isDirectory()) { if (!/[\\/]vendor$/.test(file)) walk(file); continue; }
    if (!/\.(?:html|js|css|json|md)$/i.test(name)) continue;
    const content = readFileSync(file, "utf8").replace(/http:\/\/schemas\.(?:openxmlformats|microsoft)\.org\/[A-Za-z0-9_./-]+/g, "OOXML_NAMESPACE");
    forbidden.forEach((pattern) => { if (pattern.test(content)) failures.push(`${relative(root, file)}: ${pattern}`); });
  }
}
walk(root);
if (failures.length) { console.error("Dependências ou chamadas externas encontradas:\n" + failures.join("\n")); process.exit(1); }
console.log("✓ Nenhuma chamada de rede, CDN ou URL externa encontrada fora das bibliotecas empacotadas.");
