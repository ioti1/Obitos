(function (root, factory) {
  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVXlsx = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  function colName(n) { let out = ""; while (n >= 0) { out = String.fromCharCode((n % 26) + 65) + out; n = Math.floor(n / 26) - 1; } return out; }
  function colIndex(ref) { let n = 0; for (const ch of ref.replace(/[0-9]/g, "")) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; }
  function escapeXml(value) { return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function parseXml(xml) { return new DOMParser().parseFromString(xml, "application/xml"); }
  function cellText(cell, shared) {
    const type = cell.getAttribute("t");
    if (type === "s") return shared[Number(cell.getElementsByTagName("v")[0]?.textContent || 0)] || "";
    if (type === "inlineStr") return [...cell.getElementsByTagName("t")].map((item) => item.textContent || "").join("");
    return cell.getElementsByTagName("v")[0]?.textContent || "";
  }
  async function read(file) {
    if (!root.JSZip) throw new Error("Biblioteca local de Excel não foi carregada.");
    if (!/\.xlsx$/i.test(file.name || "")) throw new Error("Use arquivo .xlsx. O formato .xls legado não é suportado nesta versão.");
    const zip = await root.JSZip.loadAsync(await file.arrayBuffer());
    const workbookEntry = zip.file("xl/workbook.xml");
    const relEntry = zip.file("xl/_rels/workbook.xml.rels");
    if (!workbookEntry || !relEntry) throw new Error("Arquivo XLSX inválido ou incompleto.");
    const workbook = parseXml(await workbookEntry.async("string"));
    const relationships = parseXml(await relEntry.async("string"));
    const rels = {};
    [...relationships.getElementsByTagName("Relationship")].forEach((rel) => { rels[rel.getAttribute("Id")] = rel.getAttribute("Target"); });
    let shared = [];
    if (zip.file("xl/sharedStrings.xml")) {
      const doc = parseXml(await zip.file("xl/sharedStrings.xml").async("string"));
      shared = [...doc.getElementsByTagName("si")].map((item) => [...item.getElementsByTagName("t")].map((node) => node.textContent || "").join(""));
    }
    const sheets = {};
    for (const sheet of [...workbook.getElementsByTagName("sheet")]) {
      const name = sheet.getAttribute("name") || "Planilha";
      const id = sheet.getAttribute("r:id") || sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
      let target = rels[id] || "";
      target = target.replace(/^\/?xl\//, "");
      const entry = zip.file(`xl/${target}`);
      if (!entry) continue;
      const doc = parseXml(await entry.async("string"));
      const rows = [];
      [...doc.getElementsByTagName("row")].forEach((row) => {
        const values = [];
        [...row.getElementsByTagName("c")].forEach((cell) => { values[colIndex(cell.getAttribute("r") || "A1")] = cellText(cell, shared); });
        rows.push(values.map((value) => value ?? ""));
      });
      sheets[name] = rows;
    }
    return sheets;
  }
  function normalizeSheet(data) {
    if (!data?.length) return [[]];
    if (Array.isArray(data[0])) return data;
    const headers = [...new Set(data.flatMap((row) => Object.keys(row)))];
    return [headers, ...data.map((row) => headers.map((header) => row[header] ?? ""))];
  }
  function sheetXml(rows) {
    const xmlRows = rows.map((row, r) => `<row r="${r + 1}">${row.map((cell, c) => `<c r="${colName(c)}${r + 1}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(cell)}</t></is></c>`).join("")}</row>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${xmlRows}</sheetData></worksheet>`;
  }
  async function write(sheetMap) {
    if (!root.JSZip) throw new Error("Biblioteca local de Excel não foi carregada.");
    const zip = new root.JSZip();
    const entries = Object.entries(sheetMap).map(([name, data]) => [String(name).slice(0, 31), normalizeSheet(data)]);
    const overrides = entries.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("");
    zip.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${overrides}</Types>`);
    zip.folder("_rels").file(".rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
    zip.folder("xl").file("workbook.xml", `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${entries.map(([name], i) => `<sheet name="${escapeXml(name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`);
    zip.folder("xl").folder("_rels").file("workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${entries.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}</Relationships>`);
    const folder = zip.folder("xl").folder("worksheets");
    entries.forEach(([, rows], i) => folder.file(`sheet${i + 1}.xml`, sheetXml(rows)));
    return zip.generateAsync({ type: "blob", compression: "DEFLATE", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  }

  return { read, write, normalizeSheet, colName, colIndex };
});
