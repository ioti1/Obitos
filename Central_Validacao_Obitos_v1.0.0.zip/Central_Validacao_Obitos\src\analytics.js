(function (root, factory) {
  const deps = typeof module === "object" && module.exports ? { utils: require("./utils.js") } : { utils: root.CVUtils };
  const api = factory(deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVAnalytics = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";

  function ageBand(age) {
    if (age == null || Number.isNaN(Number(age))) return "Não calculada";
    const value = Number(age);
    if (value < 40) return "Até 39";
    if (value < 60) return "40 a 59";
    if (value < 70) return "60 a 69";
    if (value < 80) return "70 a 79";
    if (value < 90) return "80 a 89";
    return "90 ou mais";
  }

  function summarize(records, sourceCounts) {
    const confirmed = records.filter((row) => row.classificacao === "Confirmado");
    const possible = records.filter((row) => row.classificacao === "Possível");
    const matched = records.filter((row) => row.matchStatus === "Com correspondência");
    const ages = confirmed.map((row) => row.idadeObito).filter((value) => value != null && Number.isFinite(Number(value)));
    const indicators = {
      total_base: Number(sourceCounts?.base || 0),
      total_retorno: Number(sourceCounts?.returned || 0),
      total_processados: records.length,
      correspondencias: matched.length,
      retornos_sem_cadastro: records.filter((row) => row.matchStatus === "Retorno sem cadastro").length,
      cadastros_sem_retorno: records.filter((row) => row.matchStatus === "Cadastro sem retorno").length,
      obitos_confirmados: confirmed.length,
      obitos_possiveis: possible.length,
      sem_obito: records.filter((row) => row.classificacao === "Sem óbito").length,
      novos_obitos_id2: records.filter((row) => row.novoObitoId2).length,
      obitos_recentes: records.filter((row) => row.obitoRecente).length,
      presumidos_confirmados_id1: records.filter((row) => row.presumidoConfirmadoId1).length,
      dependentes_id3_com_obito: records.filter((row) => row.dependenteComObitoId3).length,
      taxa_obito_confirmado: records.length ? confirmed.length / records.length : 0,
      taxa_match_cadastral: Number(sourceCounts?.returned) ? matched.length / Number(sourceCounts.returned) : 0,
      idade_media_obito: ages.length ? ages.reduce((sum, value) => sum + Number(value), 0) / ages.length : null,
      inconsistencias: records.reduce((sum, row) => sum + row.inconsistencias.length, 0)
    };
    const distributions = {
      classificacao: U.groupCount(records, "classificacao"),
      id: U.groupCount(records, "id"),
      situacao: U.groupCount(records, "situacao"),
      plano: U.groupCount(records, "plano"),
      patrocinadora: U.groupCount(records, "patrocinadora"),
      uf: U.groupCount(records, "uf"),
      faixa_etaria: U.groupCount(records, (row) => ageBand(row.idadeObito))
    };
    return { indicators, distributions };
  }

  function historyEntry(context, summary) {
    return {
      competencia: context.competence,
      data_processamento: new Date().toISOString(),
      arquivos: { base_cadastral: context.baseName || "", retorno_ph3a: context.returnName || "" },
      hashes: { base_cadastral: context.baseHash || "indisponível", retorno_ph3a: context.returnHash || "indisponível" },
      indicadores: summary.indicators,
      distribuicoes: summary.distributions,
      versao_regras: context.rulesVersion || "1.0.0"
    };
  }

  function upsertHistory(history, entry) {
    const target = history && Array.isArray(history.apuracoes) ? history : { versao_schema: "1.0", apuracoes: [] };
    const index = target.apuracoes.findIndex((item) => item.competencia === entry.competencia);
    if (index >= 0) target.apuracoes[index] = entry; else target.apuracoes.push(entry);
    target.apuracoes.sort((a, b) => String(a.competencia).localeCompare(String(b.competencia)));
    return target;
  }

  return { ageBand, summarize, historyEntry, upsertHistory };
});
