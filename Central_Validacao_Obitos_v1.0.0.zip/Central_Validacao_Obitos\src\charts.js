(function (root, factory) {
  const api = factory(root.CVUtils || (typeof require === "function" ? require("./utils.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCharts = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";
  const COLORS = ["#17847b", "#2a6ba7", "#de8e28", "#6fa399", "#e2c26f", "#173f3a", "#a1c3bd"];
  function entries(data, limit) { return Object.entries(data || {}).sort((a, b) => Number(b[1]) - Number(a[1])).slice(0, limit || 8); }
  function bar(data, options) {
    const list = entries(data, options?.limit || 8);
    const max = Math.max(1, ...list.map(([, value]) => Number(value)));
    if (!list.length) return `<div class="chart-empty">Sem dados para exibir</div>`;
    return `<div class="bar-chart" role="img" aria-label="${U.escapeHtml(options?.label || "Gráfico de barras")}">${list.map(([label, value], index) => `<div class="bar-row"><span class="bar-label" title="${U.escapeHtml(label)}">${U.escapeHtml(label)}</span><span class="bar-track"><i style="width:${Math.max(3, Number(value) / max * 100)}%;background:${COLORS[index % COLORS.length]}"></i></span><strong>${U.formatNumber(value, 0)}</strong></div>`).join("")}</div>`;
  }
  function line(points, key, options) {
    const values = (points || []).map((item) => Number(item.indicadores?.[key] || 0));
    if (!values.length) return `<div class="chart-empty">Importe ou processe competências para formar a série.</div>`;
    const width = 760, height = 220, pad = 34, max = Math.max(1, ...values);
    const coords = values.map((value, index) => {
      const x = values.length === 1 ? width / 2 : pad + index * (width - pad * 2) / (values.length - 1);
      const y = height - pad - (value / max) * (height - pad * 2);
      return { x, y, value, label: points[index].competencia };
    });
    return `<svg class="line-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${U.escapeHtml(options?.label || "Série histórica")}"><line x1="${pad}" y1="${height-pad}" x2="${width-pad}" y2="${height-pad}" class="axis"/><polyline points="${coords.map((p) => `${p.x},${p.y}`).join(" ")}" fill="none" stroke="${options?.color || COLORS[0]}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>${coords.map((p) => `<g><circle cx="${p.x}" cy="${p.y}" r="5" fill="${options?.color || COLORS[0]}"/><text x="${p.x}" y="${Math.max(14, p.y - 12)}" text-anchor="middle" class="value">${U.formatNumber(p.value, 0)}</text><text x="${p.x}" y="${height - 10}" text-anchor="middle" class="label">${U.escapeHtml(p.label)}</text></g>`).join("")}</svg>`;
  }
  return { bar, line, COLORS };
});
