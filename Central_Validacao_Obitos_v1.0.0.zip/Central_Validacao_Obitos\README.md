# Central de Validação de Óbitos Petros

Aplicação interna, local e offline para validar e cruzar mensalmente a base cadastral Qlikview com o retorno enriquecido da Ph3a.

## Como abrir

1. Abra `index.html` diretamente no Microsoft Edge ou acesse a aplicação pelo `HUB Cadastro v4.html` do diretório superior.
2. Informe a competência.
3. Selecione os dois arquivos `.xlsx` e confirme as abas.
4. Revise os alertas da validação pré-processamento.
5. Clique em **Processar competência**.

O botão **Carregar demonstração** executa o fluxo sem dados reais.

## Histórico

- O navegador mantém uma cópia conveniente em `localStorage`.
- No início do trabalho, importe o `historico_obitos_petros.json` mais recente.
- Ao final, exporte o histórico atualizado e substitua a cópia mestre no diretório autorizado.
- Como a aplicação é HTML puro aberta por `file://`, ela não grava silenciosamente em arquivo compartilhado.

## Relatórios e exportações

- Os dois relatórios usam páginas A4 e podem ser salvos em PDF pela impressão do navegador.
- A aplicação exporta XLSX completo, novos óbitos ID 2, possíveis óbitos, inconsistências, JSON histórico e pacote ZIP.
- Arquivos seguem `CVOBITOS_PETROS_[TIPO]_[COMPETENCIA]_[DATA_GERACAO].ext`.

## Testes

Execute com o Node.js corporativo/portátil disponível:

```text
node tests/run-tests.cjs
node tests/static-checks.cjs
```

Também é possível abrir `tests/browser-tests.html` no Edge.

## Limitações da primeira versão

- Suporta `.xlsx`; arquivos `.xls` legados devem ser salvos como `.xlsx`.
- Não possui status ou comentários por matrícula, conforme o escopo aprovado.
- A persistência compartilhada exige importação/exportação manual do histórico em HTML puro.
- CPF e demais dados pessoais não são mascarados; os arquivos são de uso interno e não devem ser enviados externamente.
