import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";

const source = resolve(process.cwd(), "index.html");
const targetDir = resolve(process.cwd(), "Central_Validacao_Obitos", "vendor");
const html = await readFile(source, "utf8");
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
const jszip = scripts.map((match) => match[1]).find((body) => body.includes("JSZip v3.10.1"));

if (!jszip) throw new Error("Biblioteca JSZip embutida não encontrada no HTML de referência.");

await mkdir(targetDir, { recursive: true });
await writeFile(resolve(targetDir, "jszip.min.js"), jszip.trim() + "\n", "utf8");
console.log("JSZip local extraído com sucesso.");
