const assert = require("node:assert/strict");
const U = require("../src/utils.js");
const Rules = require("../src/rules.js");
const Validation = require("../src/validation.js");
const Analytics = require("../src/analytics.js");

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test("normaliza matrícula sem remover zeros à esquerda", () => assert.equal(U.normalizeMatricula(" 000 123 "), "000123"));
test("reconhece cabeçalho ignorando acento, caixa e espaços", () => assert.equal(U.normalizeHeader("  Matrícula   Petros "), "MATRICULA PETROS"));
test("interpreta data DD/MM/AAAA", () => assert.equal(U.dateToISO(U.parseDate("03/07/2026")), "2026-07-03"));
test("interpreta data ISO", () => assert.equal(U.dateToISO(U.parseDate("2026-07-03")), "2026-07-03"));
test("interpreta serial Excel", () => assert.equal(U.dateToISO(U.parseDate("45444")), "2024-06-01"));
test("não trata ano isolado como data completa", () => assert.equal(U.parseDate("2024"), null));
test("confirma óbito por flag", () => assert.equal(Rules.classifyDeath({ obitoEnriquecido: "sim" }).classification, "Confirmado"));
test("confirma óbito por data válida", () => assert.equal(Rules.classifyDeath({ dataObitoEnriquecido: "01/01/2025" }).classification, "Confirmado"));
test("confirma óbito por ano", () => assert.equal(Rules.classifyDeath({ anoObito: "2025" }).classification, "Confirmado"));
test("classifica possível somente sem confirmação", () => assert.equal(Rules.classifyDeath({ possivelObitoEnriquecido: "X" }).classification, "Possível"));
test("prioriza confirmação sobre possível", () => assert.equal(Rules.classifyDeath({ obitoEnriquecido: "1", possivelObitoEnriquecido: "SIM" }).classification, "Confirmado"));
test("marca novo óbito ID 2", () => assert.equal(Rules.merge({ matricula: "001" }, { matricula: "001", id: "2", obitoEnriquecido: "SIM" }).novoObitoId2, true));
test("marca retorno sem correspondência", () => assert.equal(Rules.merge(null, { matricula: "999", id: "2" }).matchStatus, "Retorno sem cadastro"));
test("calcula idade apenas com datas completas", () => {
  const full = Rules.merge({ matricula: "001", dataNascimento: "10/01/1950" }, { matricula: "001", id: "1", dataObitoEnriquecido: "09/01/2020" });
  const year = Rules.merge({ matricula: "002", dataNascimento: "10/01/1950" }, { matricula: "002", id: "1", anoObito: "2020" });
  assert.equal(full.idadeObito, 69); assert.equal(year.idadeObito, null);
});
test("identifica duplicidade de matrícula", () => assert.deepEqual(Validation.duplicateValues([{ matricula: "001" }, { matricula: "001" }], "matricula"), [{ value: "001", count: 2 }]));
test("bloqueia arquivo sem coluna essencial", () => {
  const result = Validation.analyze("base", [["Nome Participante"], ["Ana"]], {});
  assert.equal(result.blocking, true); assert.deepEqual(result.missingEssential, ["matricula"]);
});
test("reconhece IDs inválidos", () => {
  const headers = ["ID", "Matrícula Petros", "OBITO_ENRIQUECIDO", "DATA_OBITO_ENRIQUECIDO", "ANO_OBITO", "POSSIVEL_OBITO_ENRIQUECIDO", "DATA_POSSIVEL_OBITO_ENRIQUECIDO", "ANO_POSSIVEL_OBITO_ENRIQUECIDO"];
  const result = Validation.analyze("return", [headers, ["9", "001", "", "", "", "", "", ""]], {});
  assert.equal(result.invalidIds.length, 1); assert.equal(result.blocking, false);
});
test("calcula indicadores principais", () => {
  const rows = [Rules.merge({ matricula: "001" }, { matricula: "001", id: "2", obitoEnriquecido: "SIM" }), Rules.merge({ matricula: "002" }, { matricula: "002", id: "3", possivelObitoEnriquecido: "SIM" })];
  const summary = Analytics.summarize(rows, { base: 2, returned: 2 });
  assert.equal(summary.indicators.obitos_confirmados, 1); assert.equal(summary.indicators.obitos_possiveis, 1); assert.equal(summary.indicators.novos_obitos_id2, 1);
});
test("histórico substitui competência reprocessada", () => {
  const history = Analytics.upsertHistory({ versao_schema: "1.0", apuracoes: [] }, { competencia: "2026-06", indicadores: { total_processados: 1 } });
  Analytics.upsertHistory(history, { competencia: "2026-06", indicadores: { total_processados: 2 } });
  assert.equal(history.apuracoes.length, 1); assert.equal(history.apuracoes[0].indicadores.total_processados, 2);
});

let passed = 0;
for (const item of tests) {
  try { item.fn(); passed += 1; console.log(`✓ ${item.name}`); }
  catch (error) { console.error(`✗ ${item.name}`); console.error(error); process.exitCode = 1; }
}
console.log(`\n${passed}/${tests.length} testes aprovados.`);
