(function (root, factory) {
  const api = factory(root.CVUtils, root.CVXlsx);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVExports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U, Xlsx) {
  "use strict";
  function recordRows(records) {
    return (records || []).map((row) => ({
      "Matrícula Petros": row.matricula, "Nome Participante": row.nome, CPF: row.cpf, ID: row.id,
      Classificação: row.classificacao, "Data Óbito": row.dataObito || row.anoObito, "Precisão Data": row.precisaoDataObito,
      "Idade Óbito": row.idadeObito ?? "", Match: row.matchStatus, Situação: row.situacao, Plano: row.plano,
      Patrocinadora: row.patrocinadora, UF: row.uf, Evidências: row.evidencias, Inconsistências: row.inconsistencias.join("; ")
    }));
  }
  async function workbook(records, summary, competence, mode) {
    let filtered = records || [];
    if (mode === "NOVOS_OBITOS") filtered = filtered.filter((row) => row.novoObitoId2);
    if (mode === "POSSIVEIS_OBITOS") filtered = filtered.filter((row) => row.classificacao === "Possível");
    if (mode === "INCONSISTENCIAS") filtered = filtered.filter((row) => row.inconsistencias.length);
    const indicatorRows = Object.entries(summary?.indicators || {}).map(([indicator, value]) => ({ Indicador: indicator, Valor: value ?? "" }));
    const sheets = { Apuração: recordRows(filtered), Indicadores: indicatorRows };
    if (mode === "COMPLETO") {
      ["1", "2", "3"].forEach((id) => { sheets[`ID ${id}`] = recordRows(filtered.filter((row) => row.id === id)); });
      sheets.Inconsistências = recordRows(filtered.filter((row) => row.inconsistencias.length));
    }
    const blob = await Xlsx.write(sheets);
    U.downloadBlob(blob, U.filename(mode === "COMPLETO" ? "PROCESSAMENTO" : mode, competence, "xlsx"));
    return blob;
  }
  function history(history) {
    const blob = new Blob([JSON.stringify(history, null, 2)], { type: "application/json;charset=utf-8" });
    U.downloadBlob(blob, U.filename("HISTORICO", "", "json"));
    return blob;
  }
  async function packageZip(state) {
    const zip = new JSZip();
    const base = `CVOBITOS_PETROS_PACOTE_${state.competence}_${U.fileDate()}`;
    zip.file(U.filename("PROCESSAMENTO", state.competence, "xlsx"), await Xlsx.write({ Apuração: recordRows(state.records), Indicadores: Object.entries(state.summary.indicators) }));
    zip.file(U.filename("HISTORICO", "", "json"), JSON.stringify(state.history, null, 2));
    zip.file("metadados_apuracao.json", JSON.stringify({ competencia: state.competence, gerado_em: new Date().toISOString(), arquivos: [state.baseFile?.name || "demo", state.returnFile?.name || "demo"], versao_regras: "1.0.0" }, null, 2));
    const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
    U.downloadBlob(blob, `${base}.zip`);
  }
  return { recordRows, workbook, history, packageZip };
});
