(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVUtils = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function text(value) { return value == null ? "" : String(value); }
  function normalizeText(value) {
    return text(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toUpperCase();
  }
  function normalizeHeader(value) {
    return normalizeText(value).replace(/[^A-Z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function normalizeMatricula(value) {
    return text(value).trim().replace(/\s+/g, "");
  }
  function isBlank(value) { return text(value).trim() === ""; }
  function isValidYear(value) {
    if (isBlank(value)) return false;
    const year = Number(text(value).match(/\d{4}/)?.[0]);
    return Number.isInteger(year) && year >= 1900 && year <= 2200;
  }
  function excelSerialToDate(serial) {
    const value = Number(serial);
    if (!Number.isFinite(value) || value < 1 || value > 100000) return null;
    const utc = Math.round((value - 25569) * 86400 * 1000);
    const date = new Date(utc);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  function parseDate(value) {
    if (value instanceof Date && !Number.isNaN(value.getTime())) return new Date(value.getTime());
    const raw = text(value).trim();
    if (!raw) return null;
    if (/^\d+(?:[.,]\d+)?$/.test(raw)) {
      const serial = Number(raw.replace(",", "."));
      if (serial > 20000) return excelSerialToDate(serial);
      if (/^\d{4}$/.test(raw)) return null;
    }
    let match = raw.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
    if (match) {
      const date = new Date(Date.UTC(Number(match[3]), Number(match[2]) - 1, Number(match[1])));
      return date.getUTCDate() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 ? date : null;
    }
    match = raw.match(/^(\d{4})[\/.-](\d{1,2})[\/.-](\d{1,2})(?:T.*)?$/);
    if (match) {
      const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
      return date.getUTCDate() === Number(match[3]) && date.getUTCMonth() === Number(match[2]) - 1 ? date : null;
    }
    return null;
  }
  function dateToISO(date) {
    return date instanceof Date && !Number.isNaN(date.getTime()) ? date.toISOString().slice(0, 10) : "";
  }
  function formatDate(value) {
    const date = value instanceof Date ? value : parseDate(value);
    return date ? new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(date) : "-";
  }
  function ageAt(birth, event) {
    const b = parseDate(birth), e = parseDate(event);
    if (!b || !e || e < b) return null;
    let age = e.getUTCFullYear() - b.getUTCFullYear();
    const beforeBirthday = e.getUTCMonth() < b.getUTCMonth() || (e.getUTCMonth() === b.getUTCMonth() && e.getUTCDate() < b.getUTCDate());
    if (beforeBirthday) age -= 1;
    return age;
  }
  function mapHeaders(headers, aliases) {
    const normalized = headers.map(normalizeHeader);
    const mapping = {};
    Object.entries(aliases).forEach(([canonical, candidates]) => {
      const options = candidates.map(normalizeHeader);
      const index = normalized.findIndex((header) => options.includes(header));
      if (index >= 0) mapping[canonical] = index;
    });
    return mapping;
  }
  function rowsToObjects(rows, mapping) {
    return rows.slice(1).filter((row) => row.some((value) => !isBlank(value))).map((row, index) => {
      const object = { __row: index + 2 };
      Object.entries(mapping).forEach(([key, column]) => { object[key] = row[column] ?? ""; });
      return object;
    });
  }
  function slug(value) { return normalizeText(value).replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, ""); }
  function escapeHtml(value) {
    return text(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function groupCount(rows, key, fallback) {
    return rows.reduce((acc, row) => {
      const label = text(typeof key === "function" ? key(row) : row[key]).trim() || fallback || "Não informado";
      acc[label] = (acc[label] || 0) + 1;
      return acc;
    }, {});
  }
  function formatNumber(value, digits) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: digits == null ? 1 : digits }).format(Number(value) || 0);
  }
  function formatPercent(value) { return `${formatNumber((Number(value) || 0) * 100, 1)}%`; }
  function todayISO() { return new Date().toISOString().slice(0, 10); }
  function fileDate() { return todayISO(); }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = filename; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function sha256(file) {
    if (!file?.arrayBuffer || !globalThis.crypto?.subtle) return "indisponível";
    const hash = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
    return [...new Uint8Array(hash)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function filename(type, competence, extension, range) {
    const reference = range || competence || "SEM_COMPETENCIA";
    return `CVOBITOS_PETROS_${type}_${reference}_${fileDate()}.${extension}`;
  }

  return { text, normalizeText, normalizeHeader, normalizeMatricula, isBlank, isValidYear, excelSerialToDate, parseDate, dateToISO, formatDate, ageAt, mapHeaders, rowsToObjects, slug, escapeHtml, groupCount, formatNumber, formatPercent, todayISO, fileDate, downloadBlob, sha256, filename };
});
