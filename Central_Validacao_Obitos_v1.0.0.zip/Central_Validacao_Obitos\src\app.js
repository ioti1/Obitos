(function () {
  "use strict";
  const C = window.CVConfig, U = window.CVUtils, Rules = window.CVRules, Validation = window.CVValidation;
  const Analytics = window.CVAnalytics, Charts = window.CVCharts, Reports = window.CVReports, Exports = window.CVExports;

  const state = {
    competence: new Date().toISOString().slice(0, 7),
    baseFile: null, returnFile: null, baseWorkbook: null, returnWorkbook: null,
    baseValidation: null, returnValidation: null, records: [], summary: null,
    history: loadHistory(),
    settings: loadSettings()
  };

  const demoBase = [["Matrícula Petros","Nome Participante","Nome Patrocinador","Data Nascimento","Idade","Logradouro","Número","Complemento","Bairro","Cidade","CEP","UF","País","Data Óbito","Nome Plano","Situação","Tipo Benefício"],
    ["000123","Ana Ribeiro","Petrobras","15/04/1948","78","Rua A","10","","Centro","Rio de Janeiro","20000-000","RJ","Brasil","","Plano Petros 2","Assistido","Aposentadoria"],
    ["000124","Bruno Lima","Petrobras","22/08/1952","73","Rua B","20","","Copacabana","Rio de Janeiro","22000-000","RJ","Brasil","","Plano Petros 2","Assistido","Pensão"],
    ["000125","Carla Souza","BR Distribuidora","10/01/1961","65","Rua C","30","","Boa Viagem","Recife","50000-000","PE","Brasil","","Plano PPSP-R","Ativo","Aposentadoria"],
    ["000126","Daniel Rocha","Petrobras","04/06/1942","84","Rua D","40","","Centro","Salvador","40000-000","BA","Brasil","","Plano PPSP-NR","Assistido","Aposentadoria"],
    ["000127","Elisa Martins","Petrobras","27/11/1970","55","Rua E","50","","Savassi","Belo Horizonte","30000-000","MG","Brasil","","Plano Petros 2","Ativo","Aposentadoria"],
    ["000128","Fabio Nunes","Transpetro","19/03/1958","68","Rua F","60","","Centro","Vitória","29000-000","ES","Brasil","","Plano Petros 2","Assistido","Aposentadoria"],
    ["000129","Gisele Alves","Petrobras","31/12/1939","86","Rua G","70","","Centro","Curitiba","80000-000","PR","Brasil","12/02/2025","Plano PPSP-R","Assistido","Pensão"],
    ["000130","Helena Costa","Petrobras","02/05/1965","61","Rua H","80","","Centro","São Paulo","01000-000","SP","Brasil","","Plano Petros 2","Ativo","Aposentadoria"]];
  const demoReturn = [["ID","Matrícula Petros","Nome Participante","Data Nascimento","CPF","Data Óbito","Pessoa Politicamente Exposta","CPF_ENRIQUECIDO","NOME_ENRIQUECIDO","SEXO_ENRIQUECIDO","DATA_NASC_ENRIQUECIDO","PPE_ENRIQUECIDO","OBITO_ENRIQUECIDO","DATA_OBITO_ENRIQUECIDO","ANO_OBITO","NOME_ORGAO","DESCRICAO_FUNCAO","DATA_INICIO_EXERCICIO","DATA_FIM_CARREIRA","POSSIVEL_OBITO_ENRIQUECIDO","DATA_POSSIVEL_OBITO_ENRIQUECIDO","ANO_POSSIVEL_OBITO_ENRIQUECIDO"],
    ["2","000123","Ana Ribeiro","15/04/1948","11111111111","","NÃO","11111111111","Ana Ribeiro","F","15/04/1948","NÃO","SIM","03/07/2026","","","","","","NÃO","",""],
    ["1","000124","Bruno Lima","22/08/1952","22222222222","","NÃO","22222222222","Bruno Lima","M","22/08/1952","NÃO","","","2024","","","","","NÃO","",""],
    ["2","000125","Carla Souza","10/01/1961","33333333333","","NÃO","33333333333","Carla Souza","F","10/01/1961","NÃO","NÃO","","","","","","","SIM","18/06/2026",""],
    ["3","000126","Daniel Rocha","04/06/1942","44444444444","","NÃO","44444444444","Daniel Rocha","M","04/06/1942","NÃO","NÃO","","","","","","","NÃO","","2023"],
    ["2","000127","Elisa Martins","27/11/1970","55555555555","","NÃO","55555555555","Elisa Martins","F","27/11/1970","NÃO","NÃO","","","","","","","NÃO","",""],
    ["3","000128","Fabio Nunes","19/03/1958","66666666666","","NÃO","66666666666","Fábio Nunes","M","19/03/1958","NÃO","X","45444","","","","","","NÃO","",""],
    ["2","999999","Registro sem cadastro","01/01/1950","99999999999","","NÃO","99999999999","Registro sem cadastro","M","01/01/1950","NÃO","TRUE","01/07/2026","","","","","","NÃO","",""]];

  function $(selector, root) { return (root || document).querySelector(selector); }
  function $$(selector, root) { return [...(root || document).querySelectorAll(selector)]; }
  function loadSettings() {
    try { return { affirmativeValues: C.AFFIRMATIVE_VALUES, recentDays: C.RECENT_DAYS, maxAge: C.MAX_AGE, ...JSON.parse(localStorage.getItem("cvobitos_settings") || "{}") }; }
    catch { return { affirmativeValues: C.AFFIRMATIVE_VALUES, recentDays: C.RECENT_DAYS, maxAge: C.MAX_AGE }; }
  }
  function loadHistory() {
    try { const parsed = JSON.parse(localStorage.getItem("cvobitos_history") || "null"); return parsed?.apuracoes ? parsed : { versao_schema: C.HISTORY_SCHEMA, apuracoes: [] }; }
    catch { return { versao_schema: C.HISTORY_SCHEMA, apuracoes: [] }; }
  }
  function persist() {
    localStorage.setItem("cvobitos_settings", JSON.stringify(state.settings));
    localStorage.setItem("cvobitos_history", JSON.stringify(state.history));
  }
  function toast(message, type) {
    const el = $("#toast"); el.textContent = message; el.className = `toast show ${type || "info"}`;
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3500);
  }
  function setBusy(active, message) {
    $("#busy").hidden = !active; $("#busyText").textContent = message || "Processando...";
  }
  function showView(id) {
    $$(".view").forEach((view) => view.classList.toggle("active", view.id === id));
    $$("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === id));
    $("#pageTitle").textContent = $(`[data-view="${id}"]`)?.dataset.title || "Central de Validação de Óbitos";
    if (id === "reports") Reports.render(state);
    window.scrollTo(0, 0);
  }
  function populateSheetSelect(kind) {
    const workbook = state[`${kind}Workbook`];
    const select = $(`#${kind}Sheet`); select.replaceChildren();
    Object.keys(workbook || {}).forEach((name) => select.append(new Option(name, name)));
    select.disabled = !Object.keys(workbook || {}).length;
  }
  function analyze(kind) {
    const workbook = state[`${kind}Workbook`]; if (!workbook) return;
    const sheet = $(`#${kind}Sheet`).value || Object.keys(workbook)[0];
    const file = state[`${kind}File`];
    state[`${kind}Validation`] = Validation.analyze(kind === "base" ? "base" : "return", workbook[sheet], { filename: file?.name || `dados_demonstracao_${kind}.xlsx`, sheet, competence: state.competence });
    renderValidation();
  }
  async function handleFile(kind, file) {
    if (!file) return;
    setBusy(true, `Lendo ${file.name}...`);
    try {
      const workbook = await CVXlsx.read(file);
      state[`${kind}File`] = file; state[`${kind}Workbook`] = workbook;
      populateSheetSelect(kind); analyze(kind); updateFileCard(kind);
      toast(`${file.name} carregado e validado.`, "success");
    } catch (error) { toast(error.message || "Não foi possível ler o arquivo.", "error"); }
    finally { setBusy(false); }
  }
  function updateFileCard(kind) {
    const file = state[`${kind}File`], validation = state[`${kind}Validation`];
    $(`#${kind}FileName`).textContent = file?.name || (state[`${kind}Workbook`] ? "Dados de demonstração" : "Nenhum arquivo selecionado");
    const badge = $(`#${kind}Status`);
    badge.textContent = validation ? (validation.blocking ? "Bloqueado" : "Validado") : "Aguardando";
    badge.className = `status-badge ${validation ? (validation.blocking ? "danger" : "success") : "neutral"}`;
  }
  function validationCard(validation, label) {
    if (!validation) return `<article class="validation-card empty"><h3>${label}</h3><p>Carregue o arquivo para executar as verificações.</p></article>`;
    const issues = validation.missingEssential.length + validation.emptyKeys.length + validation.invalidDates.length + validation.invalidIds.length + validation.duplicates.length;
    return `<article class="validation-card ${validation.blocking ? "blocked" : "ready"}"><div class="validation-head"><div><span>${label}</span><h3>${U.escapeHtml(validation.filename)}</h3></div><span class="quality-score">${validation.blocking ? "Bloqueado" : issues ? "Com alertas" : "Aprovado"}</span></div><dl class="mini-metrics"><div><dt>Linhas</dt><dd>${validation.rowCount}</dd></div><div><dt>Colunas</dt><dd>${validation.columnCount}</dd></div><div><dt>Reconhecidas</dt><dd>${validation.recognized.length}</dd></div><div><dt>Duplicidades</dt><dd>${validation.duplicates.length}</dd></div></dl><div class="issue-list">${validation.missingEssential.length ? `<p class="error"><strong>Obrigatórias ausentes:</strong> ${validation.missingEssential.join(", ")}</p>` : ""}${validation.missingOptional.length ? `<p><strong>Opcionais ausentes:</strong> ${validation.missingOptional.slice(0, 6).join(", ")}${validation.missingOptional.length > 6 ? "..." : ""}</p>` : ""}${validation.emptyKeys.length ? `<p class="error"><strong>Matrículas vazias:</strong> linhas ${validation.emptyKeys.slice(0, 6).join(", ")}</p>` : ""}${validation.invalidDates.length ? `<p><strong>Datas inválidas:</strong> ${validation.invalidDates.length} ocorrência(s)</p>` : ""}${validation.invalidIds.length ? `<p><strong>IDs inválidos:</strong> ${validation.invalidIds.length} ocorrência(s)</p>` : ""}${validation.competenceWarning ? `<p class="warning">${U.escapeHtml(validation.competenceWarning)}</p>` : ""}</div><footer>Aba: ${U.escapeHtml(validation.sheet)}</footer></article>`;
  }
  function renderValidation() {
    $("#validationGrid").innerHTML = validationCard(state.baseValidation, "Base cadastral Qlikview") + validationCard(state.returnValidation, "Retorno Ph3a");
    const comparison = Validation.compare(state.baseValidation, state.returnValidation);
    $("#matchPreview").innerHTML = state.baseValidation && state.returnValidation ? `<strong>${U.formatPercent(comparison.rate)}</strong><span>match preliminar · ${comparison.unmatched} retorno(s) sem cadastro</span>` : `<strong>-</strong><span>aguardando os dois arquivos</span>`;
    $("#processBtn").disabled = !(state.baseValidation && state.returnValidation) || state.baseValidation?.blocking || state.returnValidation?.blocking;
  }
  async function process() {
    if ($("#processBtn").disabled) return;
    setBusy(true, "Aplicando regras, indicadores e histórico...");
    try {
      state.competence = $("#competence").value;
      state.records = Rules.process(state.baseValidation.rows, state.returnValidation.rows, state.settings);
      state.summary = Analytics.summarize(state.records, { base: state.baseValidation.rowCount, returned: state.returnValidation.rowCount });
      const [baseHash, returnHash] = await Promise.all([U.sha256(state.baseFile), U.sha256(state.returnFile)]);
      const entry = Analytics.historyEntry({ competence: state.competence, baseName: state.baseFile?.name || "demo_base.xlsx", returnName: state.returnFile?.name || "demo_retorno.xlsx", baseHash, returnHash, rulesVersion: C.RULES_VERSION }, state.summary);
      state.history = Analytics.upsertHistory(state.history, entry); persist();
      renderResults(); renderHistory(); renderExports(); Reports.render(state); showView("results");
      toast(`Competência ${state.competence} processada com sucesso.`, "success");
    } catch (error) { console.error(error); toast(error.message || "Falha no processamento.", "error"); }
    finally { setBusy(false); }
  }
  function metric(label, value, note, tone) { return `<article class="metric ${tone || ""}"><span>${label}</span><strong>${value}</strong><small>${note || ""}</small></article>`; }
  function renderResults() {
    if (!state.summary) return;
    const i = state.summary.indicators, d = state.summary.distributions;
    $("#resultPeriod").textContent = `Competência ${state.competence}`;
    $("#kpiGrid").innerHTML = metric("Processados", U.formatNumber(i.total_processados, 0), `${i.total_base} cadastrais · ${i.total_retorno} retornos`) + metric("Óbitos confirmados", U.formatNumber(i.obitos_confirmados, 0), U.formatPercent(i.taxa_obito_confirmado), "accent") + metric("Possíveis óbitos", U.formatNumber(i.obitos_possiveis, 0), "exigem análise", "warning") + metric("Novos óbitos ID 2", U.formatNumber(i.novos_obitos_id2, 0), "prioridade operacional", "danger") + metric("Match cadastral", U.formatPercent(i.taxa_match_cadastral), `${i.retornos_sem_cadastro} sem cadastro`, "blue") + metric("Inconsistências", U.formatNumber(i.inconsistencias, 0), "apontamentos de qualidade");
    $("#classChart").innerHTML = Charts.bar(d.classificacao, { label: "Classificação de óbito" });
    $("#idChart").innerHTML = Charts.bar(d.id, { label: "Distribuição por ID" });
    $("#ufChart").innerHTML = Charts.bar(d.uf, { label: "Distribuição por UF", limit: 10 });
    renderTable(); renderIssues();
  }
  function filteredRecords() {
    const search = U.normalizeText($("#tableSearch")?.value || "");
    const classification = $("#filterClassification")?.value || "";
    const id = $("#filterId")?.value || "";
    return state.records.filter((row) => (!classification || row.classificacao === classification) && (!id || row.id === id) && (!search || U.normalizeText(`${row.matricula} ${row.nome} ${row.cpf} ${row.plano} ${row.patrocinadora}`).includes(search)));
  }
  function renderTable() {
    const rows = filteredRecords();
    $("#tableCount").textContent = `${rows.length} registro(s)`;
    $("#resultTableBody").innerHTML = rows.slice(0, 250).map((row, index) => `<tr data-record="${state.records.indexOf(row)}"><td><strong>${U.escapeHtml(row.matricula)}</strong><small>${U.escapeHtml(row.nome)}</small></td><td><span class="pill id">ID ${U.escapeHtml(row.id || "-")}</span></td><td><span class="pill ${row.classificacao === "Confirmado" ? "confirmed" : row.classificacao === "Possível" ? "possible" : "clear"}">${row.classificacao}</span></td><td>${U.escapeHtml(row.dataObito || row.anoObito || "-")}<small>${U.escapeHtml(row.precisaoDataObito)}</small></td><td>${row.idadeObito ?? "-"}</td><td>${U.escapeHtml(row.plano)}</td><td>${U.escapeHtml(row.uf)}</td><td><span class="pill ${row.inconsistencias.length ? "issue" : "ok"}">${row.inconsistencias.length ? `${row.inconsistencias.length} alerta(s)` : "Consistente"}</span></td></tr>`).join("");
  }
  function renderIssues() {
    const issues = state.records.filter((row) => row.inconsistencias.length);
    $("#issueCount").textContent = `${issues.length} registro(s)`;
    $("#issueList").innerHTML = issues.length ? issues.map((row) => `<article class="issue-item"><div><strong>${U.escapeHtml(row.matricula)} · ${U.escapeHtml(row.nome)}</strong><span>${U.escapeHtml(row.inconsistencias.join(" · "))}</span></div><button class="text-button" data-open-record="${state.records.indexOf(row)}">Ver registro</button></article>`).join("") : `<div class="empty-state">Nenhuma inconsistência identificada.</div>`;
  }
  function openRecord(index) {
    const row = state.records[Number(index)]; if (!row) return;
    $("#recordModalBody").innerHTML = `<div class="record-hero"><div><span>Matrícula Petros</span><h2>${U.escapeHtml(row.matricula)}</h2><p>${U.escapeHtml(row.nome)}</p></div><span class="pill ${row.classificacao === "Confirmado" ? "confirmed" : row.classificacao === "Possível" ? "possible" : "clear"}">${row.classificacao}</span></div><dl class="record-grid">${[["ID", row.id],["CPF", row.cpf],["Match", row.matchStatus],["Data de óbito", row.dataObito || row.anoObito || "-"],["Precisão", row.precisaoDataObito],["Idade de óbito", row.idadeObito ?? "-"],["Plano", row.plano],["Patrocinadora", row.patrocinadora],["Situação", row.situacao],["UF", row.uf],["Evidências", row.evidencias],["Inconsistências", row.inconsistencias.join("; ") || "Nenhuma"]].map(([label, value]) => `<div><dt>${label}</dt><dd>${U.escapeHtml(value)}</dd></div>`).join("")}</dl>`;
    $("#recordModal").showModal();
  }
  function renderHistory() {
    const history = state.history.apuracoes || [];
    $("#historySeries").innerHTML = Charts.line(history, "total_processados", { label: "Evolução de dados processados" });
    $("#historyDeaths").innerHTML = Charts.line(history, "obitos_confirmados", { label: "Evolução de óbitos confirmados", color: "#de8e28" });
    $("#historyTableBody").innerHTML = history.map((item) => `<tr><td><strong>${U.escapeHtml(item.competencia)}</strong></td><td>${U.formatNumber(item.indicadores?.total_processados, 0)}</td><td>${U.formatNumber(item.indicadores?.obitos_confirmados, 0)}</td><td>${U.formatNumber(item.indicadores?.obitos_possiveis, 0)}</td><td>${U.formatNumber(item.indicadores?.novos_obitos_id2, 0)}</td><td>${U.formatPercent(item.indicadores?.taxa_match_cadastral)}</td><td>${U.formatNumber(item.indicadores?.inconsistencias, 0)}</td></tr>`).join("");
    $("#historyEmpty").hidden = history.length > 0;
  }
  function renderExports() { $$("[data-requires-results]").forEach((button) => { button.disabled = !state.summary; }); }
  async function importHistory(file) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (parsed.versao_schema !== C.HISTORY_SCHEMA || !Array.isArray(parsed.apuracoes)) throw new Error("Histórico incompatível: esperado schema 1.0 com lista de apurações.");
      state.history = parsed; persist(); renderHistory(); Reports.render(state); toast(`${parsed.apuracoes.length} competência(s) importada(s).`, "success");
    } catch (error) { toast(error.message || "Histórico inválido.", "error"); }
  }
  function loadDemo() {
    state.baseFile = null; state.returnFile = null;
    state.baseWorkbook = { Base_Cadastral: demoBase }; state.returnWorkbook = { Retorno_Ph3a: demoReturn };
    populateSheetSelect("base"); populateSheetSelect("return"); analyze("base"); analyze("return"); updateFileCard("base"); updateFileCard("return");
    toast("Dados de demonstração carregados. Revise a validação e processe.", "success");
  }
  function bindEvents() {
    $$("[data-view]").forEach((button) => button.addEventListener("click", () => showView(button.dataset.view)));
    $("#competence").value = state.competence; $("#competence").addEventListener("change", (event) => { state.competence = event.target.value; if (state.baseWorkbook) analyze("base"); if (state.returnWorkbook) analyze("return"); });
    $("#baseFile").addEventListener("change", (event) => handleFile("base", event.target.files[0]));
    $("#returnFile").addEventListener("change", (event) => handleFile("return", event.target.files[0]));
    $("#baseSheet").addEventListener("change", () => analyze("base")); $("#returnSheet").addEventListener("change", () => analyze("return"));
    $("#demoBtn").addEventListener("click", loadDemo); $("#processBtn").addEventListener("click", process);
    ["#tableSearch", "#filterClassification", "#filterId"].forEach((selector) => $(selector).addEventListener("input", renderTable));
    $("#resultTableBody").addEventListener("click", (event) => { const row = event.target.closest("tr[data-record]"); if (row) openRecord(row.dataset.record); });
    $("#issueList").addEventListener("click", (event) => { const button = event.target.closest("[data-open-record]"); if (button) openRecord(button.dataset.openRecord); });
    $("#closeRecordModal").addEventListener("click", () => $("#recordModal").close());
    $("#historyFile").addEventListener("change", (event) => importHistory(event.target.files[0]));
    $("#exportHistoryBtn").addEventListener("click", () => Exports.history(state.history));
    $$("[data-export]").forEach((button) => button.addEventListener("click", async () => { setBusy(true, "Gerando arquivo Excel..."); try { await Exports.workbook(state.records, state.summary, state.competence, button.dataset.export); toast("Exportação gerada.", "success"); } catch (error) { toast(error.message, "error"); } finally { setBusy(false); } }));
    $("#packageBtn").addEventListener("click", async () => { setBusy(true, "Montando pacote de apuração..."); try { await Exports.packageZip(state); toast("Pacote ZIP gerado.", "success"); } catch (error) { toast(error.message, "error"); } finally { setBusy(false); } });
    $$("[data-print]").forEach((button) => button.addEventListener("click", () => Reports.print(button.dataset.print)));
    $("#settingsForm").addEventListener("submit", (event) => { event.preventDefault(); state.settings = { affirmativeValues: $("#affirmativeValues").value.split(",").map((value) => value.trim()).filter(Boolean), recentDays: Number($("#recentDays").value) || C.RECENT_DAYS, maxAge: Number($("#maxAge").value) || C.MAX_AGE }; persist(); toast("Configurações salvas localmente.", "success"); });
  }
  function initializeSettings() { $("#affirmativeValues").value = state.settings.affirmativeValues.join(", "); $("#recentDays").value = state.settings.recentDays; $("#maxAge").value = state.settings.maxAge; }
  function init() { bindEvents(); initializeSettings(); renderValidation(); renderHistory(); renderExports(); Reports.render(state); showView("processing"); }
  document.addEventListener("DOMContentLoaded", init);
})();
