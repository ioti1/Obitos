(function (root, factory) {
  const deps = typeof module === "object" && module.exports
    ? { config: require("./config.js"), utils: require("./utils.js") }
    : { config: root.CVConfig, utils: root.CVUtils };
  const api = factory(deps.config, deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVValidation = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (Config, U) {
  "use strict";

  function duplicateValues(objects, field) {
    const counts = new Map();
    objects.forEach((row) => {
      const value = U.normalizeMatricula(row[field]);
      if (value) counts.set(value, (counts.get(value) || 0) + 1);
    });
    return [...counts.entries()].filter(([, count]) => count > 1).map(([value, count]) => ({ value, count }));
  }

  function invalidDates(objects, fields) {
    const issues = [];
    objects.forEach((row) => fields.forEach((field) => {
      const value = row[field];
      if (!U.isBlank(value) && !U.parseDate(value) && !U.isValidYear(value)) issues.push({ row: row.__row, field, value });
    }));
    return issues;
  }

  function analyze(kind, rows, meta) {
    const aliases = kind === "base" ? Config.BASE_COLUMNS : Config.RETURN_COLUMNS;
    const essentials = kind === "base" ? Config.ESSENTIAL_BASE : Config.ESSENTIAL_RETURN;
    const headers = rows[0] || [];
    const mapping = U.mapHeaders(headers, aliases);
    const objects = U.rowsToObjects(rows, mapping);
    const missingEssential = essentials.filter((key) => mapping[key] == null);
    const missingOptional = Object.keys(aliases).filter((key) => mapping[key] == null && !essentials.includes(key));
    const duplicates = duplicateValues(objects, "matricula");
    const emptyKeys = objects.filter((row) => U.isBlank(row.matricula)).map((row) => row.__row);
    const dateFields = kind === "base"
      ? ["dataNascimento", "dataObitoCadastral"]
      : ["dataNascimento", "dataNascEnriquecido", "dataObito", "dataObitoEnriquecido", "dataPossivelObitoEnriquecido", "dataInicioExercicio", "dataFimCarreira"];
    const badDates = invalidDates(objects, dateFields.filter((field) => mapping[field] != null));
    const invalidIds = kind === "return" ? objects.filter((row) => !U.isBlank(row.id) && !["1", "2", "3"].includes(String(row.id).trim())).map((row) => ({ row: row.__row, value: row.id })) : [];
    const competence = String(meta?.competence || "");
    const filename = String(meta?.filename || "");
    const competenceWarning = competence && /\d{4}[-_]\d{2}/.test(filename) && !filename.replace("_", "-").includes(competence)
      ? `O nome do arquivo pode indicar competência diferente de ${competence}.` : "";
    return {
      kind,
      filename: filename || "Arquivo sem nome",
      sheet: meta?.sheet || "Primeira aba",
      rowCount: objects.length,
      columnCount: headers.length,
      recognized: Object.keys(mapping),
      missingEssential,
      missingOptional,
      duplicates,
      emptyKeys,
      invalidDates: badDates,
      invalidIds,
      competenceWarning,
      blocking: missingEssential.length > 0 || emptyKeys.length === objects.length || objects.length === 0,
      rows: objects
    };
  }

  function compare(baseValidation, returnValidation) {
    if (!baseValidation?.rows || !returnValidation?.rows) return { match: 0, unmatched: 0, rate: 0, samples: [] };
    const baseKeys = new Set(baseValidation.rows.map((row) => U.normalizeMatricula(row.matricula)).filter(Boolean));
    const unmatchedRows = returnValidation.rows.filter((row) => !baseKeys.has(U.normalizeMatricula(row.matricula)));
    const total = returnValidation.rows.length;
    return { match: total - unmatchedRows.length, unmatched: unmatchedRows.length, rate: total ? (total - unmatchedRows.length) / total : 0, samples: unmatchedRows.slice(0, 5).map((row) => row.matricula) };
  }

  return { duplicateValues, invalidDates, analyze, compare };
});
