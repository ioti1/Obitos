(function (root, factory) {
  const api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVXlsx = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  function colName(n) { let out = ""; while (n >= 0) { out = String.fromCharCode((n % 26) + 65) + out; n = Math.floor(n / 26) - 1; } return out; }
  function colIndex(ref) { let n = 0; for (const ch of ref.replace(/[0-9]/g, "")) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; }
  function escapeXml(value) { return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function decodeXml(value) {
    return String(value || "")
      .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&")
      .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
      .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)))
      .replace(/_x([0-9a-f]{4})_/gi, (_, code) => String.fromCharCode(parseInt(code, 16)));
  }
  function textNodes(xml) {
    const values = [];
    const pattern = /<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g;
    let match;
    while ((match = pattern.exec(xml))) values.push(decodeXml(match[1]));
    return values.join("");
  }
  function attribute(attributes, name) {
    const escaped = String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return decodeXml(attributes.match(new RegExp(`(?:^|\\s)${escaped}="([^"]*)"`))?.[1] || "");
  }
  function workbookSheets(xml) {
    const sheets = [];
    const pattern = /<(?:\w+:)?sheet\b([^>]*)\/?\s*>/g;
    let match;
    while ((match = pattern.exec(xml))) sheets.push({ name: attribute(match[1], "name") || "Planilha", id: attribute(match[1], "r:id") || attribute(match[1], "id") });
    return sheets;
  }
  function workbookRelationships(xml) {
    const relationships = {};
    const pattern = /<(?:\w+:)?Relationship\b([^>]*)\/?\s*>/g;
    let match;
    while ((match = pattern.exec(xml))) relationships[attribute(match[1], "Id")] = attribute(match[1], "Target");
    return relationships;
  }
  async function sharedStrings(xml, onProgress) {
    const values = [];
    const pattern = /<(?:\w+:)?si\b[^>]*>([\s\S]*?)<\/(?:\w+:)?si>/g;
    let match; let index = 0;
    while ((match = pattern.exec(xml))) {
      values.push(textNodes(match[1])); index += 1;
      if (index % 5000 === 0) { onProgress?.(index); await new Promise((resolve) => setTimeout(resolve, 0)); }
    }
    return values;
  }
  function cellValueFromXml(attributes, body, shared) {
    const type = attributes.match(/\bt="([^"]+)"/)?.[1] || "";
    if (type === "inlineStr") return textNodes(body);
    const raw = body.match(/<(?:\w+:)?v\b[^>]*>([\s\S]*?)<\/(?:\w+:)?v>/)?.[1] || "";
    if (type === "s") return shared[Number(raw)] || "";
    return decodeXml(raw);
  }
  async function worksheetRows(xml, shared, onProgress) {
    const dimensionRef = xml.match(/<(?:\w+:)?dimension\b[^>]*\bref="([^"]+)"/i)?.[1] || "";
    const estimated = Number(dimensionRef.split(":").pop()?.match(/\d+$/)?.[0] || 0);
    const rows = [];
    const rowPattern = /<(?:\w+:)?row\b[^>]*>([\s\S]*?)<\/(?:\w+:)?row>/g;
    let rowMatch; let rowIndex = 0;
    while ((rowMatch = rowPattern.exec(xml))) {
      const values = [];
      const cellPattern = /<(?:\w+:)?c\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?c>/g;
      let cellMatch; let lastColumn = -1;
      while ((cellMatch = cellPattern.exec(rowMatch[1]))) {
        const reference = cellMatch[1].match(/\br="([^"]+)"/)?.[1] || "A1";
        const column = colIndex(reference);
        values[column] = cellValueFromXml(cellMatch[1], cellMatch[2], shared);
        if (column > lastColumn) lastColumn = column;
      }
      rows.push(lastColumn < 0 ? [] : Array.from({ length: lastColumn + 1 }, (_, column) => values[column] ?? ""));
      rowIndex += 1;
      if (rowIndex % 2500 === 0) {
        onProgress?.(rowIndex, Math.max(estimated, rowIndex));
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }
    onProgress?.(rowIndex, Math.max(estimated, rowIndex));
    return rows;
  }
  function cellText(cell, shared) {
    const type = cell.getAttribute("t");
    if (type === "s") return shared[Number(cell.getElementsByTagName("v")[0]?.textContent || 0)] || "";
    if (type === "inlineStr") return [...cell.getElementsByTagName("t")].map((item) => item.textContent || "").join("");
    return cell.getElementsByTagName("v")[0]?.textContent || "";
  }
  function readFileBytes(file, onProgress) {
    if (typeof FileReader === "undefined") return file.arrayBuffer();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onprogress = (event) => {
        if (event.lengthComputable) onProgress?.({ percent: 8 * event.loaded / event.total, phase: "Lendo arquivo local", detail: `${Math.round(event.loaded / 1048576)} de ${Math.max(1, Math.round(event.total / 1048576))} MB` });
      };
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error("Não foi possível ler o arquivo local."));
      reader.readAsArrayBuffer(file);
    });
  }
  async function read(file, onProgress) {
    if (!root.JSZip) throw new Error("Biblioteca local de Excel não foi carregada.");
    if (!/\.xlsx$/i.test(file.name || "")) throw new Error("Use arquivo .xlsx. O formato .xls legado não é suportado nesta versão.");
    const report = (percent, phase, detail) => onProgress?.({ percent: Math.max(0, Math.min(100, percent)), phase, detail });
    report(0, "Preparando leitura", file.name || "Arquivo XLSX");
    const zip = await root.JSZip.loadAsync(await readFileBytes(file, onProgress));
    report(9, "Abrindo estrutura XLSX", "Pacote local validado");
    const workbookEntry = zip.file("xl/workbook.xml");
    const relEntry = zip.file("xl/_rels/workbook.xml.rels");
    if (!workbookEntry || !relEntry) throw new Error("Arquivo XLSX inválido ou incompleto.");
    const workbookXml = await workbookEntry.async("string", (meta) => report(9 + meta.percent * 0.03, "Lendo catálogo de abas", `${Math.round(meta.percent)}% do catálogo`));
    const relationshipXml = await relEntry.async("string", (meta) => report(12 + meta.percent * 0.02, "Lendo relações internas", `${Math.round(meta.percent)}% das relações`));
    const sheetNodes = workbookSheets(workbookXml);
    const rels = workbookRelationships(relationshipXml);
    let shared = [];
    if (zip.file("xl/sharedStrings.xml")) {
      const sharedXml = await zip.file("xl/sharedStrings.xml").async("string", (meta) => report(14 + meta.percent * 0.08, "Lendo textos compartilhados", `${Math.round(meta.percent)}% dos textos`));
      shared = await sharedStrings(sharedXml, (index) => report(Math.min(25.8, 22 + Math.log10(Math.max(index, 1)) * 0.8), "Indexando textos compartilhados", `${index} textos indexados`));
    }
    const sheets = {};
    for (let sheetIndex = 0; sheetIndex < sheetNodes.length; sheetIndex += 1) {
      const sheet = sheetNodes[sheetIndex];
      const name = sheet.name;
      const id = sheet.id;
      let target = rels[id] || "";
      target = target.replace(/^\/?xl\//, "");
      const entry = zip.file(`xl/${target}`);
      if (!entry) continue;
      const sheetStart = 26 + 72 * sheetIndex / Math.max(sheetNodes.length, 1);
      const sheetWidth = 72 / Math.max(sheetNodes.length, 1);
      const xml = await entry.async("string", (meta) => report(sheetStart + sheetWidth * 0.45 * meta.percent / 100, `Descompactando aba ${name}`, `${Math.round(meta.percent)}% da aba`));
      report(sheetStart + sheetWidth * 0.47, `Interpretando aba ${name}`, "Convertendo XML em linhas sem bloquear a interface");
      const rows = await worksheetRows(xml, shared, (rowIndex, totalRows) => report(sheetStart + sheetWidth * (0.5 + 0.48 * rowIndex / Math.max(totalRows, 1)), `Lendo linhas da aba ${name}`, `${rowIndex} de ${totalRows} linhas`));
      sheets[name] = rows;
    }
    report(100, "Leitura concluída", `${Object.keys(sheets).length} aba(s) carregada(s)`);
    return sheets;
  }
  function normalizeSheet(data) {
    if (!data?.length) return [[]];
    if (Array.isArray(data[0])) return data;
    const headers = [...new Set(data.flatMap((row) => Object.keys(row)))];
    return [headers, ...data.map((row) => headers.map((header) => row[header] ?? ""))];
  }
  function sheetXml(rows) {
    const maxColumns = Math.max(1, ...rows.map((row) => row.length));
    const lastCell = `${colName(maxColumns - 1)}${Math.max(rows.length, 1)}`;
    const widths = Array.from({ length: maxColumns }, (_, column) => {
      const longest = rows.slice(0, 250).reduce((max, row) => Math.max(max, String(row[column] ?? "").length), 0);
      return Math.max(10, Math.min(36, longest + 2));
    });
    const columns = widths.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join("");
    const xmlRows = rows.map((row, r) => {
      const wrappedLines = Math.max(1, ...row.map((cell, c) => Math.ceil(String(cell ?? "").length / Math.max(widths[c] - 1, 1))));
      const height = r === 0 ? 28 : Math.min(72, Math.max(20, wrappedLines * 15));
      return `<row r="${r + 1}" ht="${height}" customHeight="1">${row.map((cell, c) => `<c r="${colName(c)}${r + 1}" t="inlineStr" s="${r === 0 ? 1 : 2}"><is><t xml:space="preserve">${escapeXml(cell)}</t></is></c>`).join("")}</row>`;
    }).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${lastCell}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${columns}</cols><sheetData>${xmlRows}</sheetData><autoFilter ref="A1:${lastCell}"/></worksheet>`;
  }
  async function write(sheetMap) {
    if (!root.JSZip) throw new Error("Biblioteca local de Excel não foi carregada.");
    const zip = new root.JSZip();
    const entries = Object.entries(sheetMap).map(([name, data]) => [String(name).slice(0, 31), normalizeSheet(data)]);
    const overrides = entries.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("");
    zip.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${overrides}</Types>`);
    zip.folder("_rels").file(".rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
    zip.folder("xl").file("workbook.xml", `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${entries.map(([name], i) => `<sheet name="${escapeXml(name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`);
    zip.folder("xl").folder("_rels").file("workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${entries.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${entries.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    zip.folder("xl").file("styles.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Arial"/><color rgb="FF173F3A"/></font><font><b/><sz val="10"/><name val="Arial"/><color rgb="FFFFFFFF"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF021832"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><bottom style="thin"><color rgb="FF17847B"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`);
    const folder = zip.folder("xl").folder("worksheets");
    entries.forEach(([, rows], i) => folder.file(`sheet${i + 1}.xml`, sheetXml(rows)));
    return zip.generateAsync({ type: "blob", compression: "DEFLATE", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  }

  return { read, write, normalizeSheet, colName, colIndex };
});
