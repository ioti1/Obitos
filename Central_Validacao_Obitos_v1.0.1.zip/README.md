# Central de Validação de Óbitos Petros

Aplicação interna, local e offline para validar e cruzar mensalmente a base cadastral Qlikview com o retorno enriquecido da Ph3a.

## Como abrir

1. Abra `index.html` diretamente no Microsoft Edge ou acesse a aplicação pelo `HUB Cadastro v4.html` do diretório superior.
2. Informe a competência.
3. Selecione os dois arquivos `.xlsx` e confirme as abas.
4. Revise os alertas da validação pré-processamento.
5. Clique em **Processar competência**.

O carregamento dos dois arquivos e o processamento exibem percentual, tempo decorrido, etapa atual e tempo restante estimado. As operações percorrem bases grandes em blocos para manter a interface responsiva.

O botão **Carregar demonstração** executa o fluxo sem dados reais.

## Histórico

- O navegador mantém uma cópia conveniente em `localStorage`.
- No início do trabalho, importe o `historico_obitos_petros.json` mais recente.
- Ao final, exporte o histórico atualizado e substitua a cópia mestre no diretório autorizado.
- Como a aplicação é HTML puro aberta por `file://`, ela não grava silenciosamente em arquivo compartilhado.

## Relatórios e exportações

- Os dois relatórios usam páginas A4 e podem ser salvos em PDF pela impressão do navegador.
- A aplicação usa `ID 0` para óbitos presumidos sem data completa, `ID 1` para participantes consultados e `ID 2` para dependentes ou vinculados.
- A aplicação exporta XLSX completo, novos óbitos de participantes ID 1, possíveis óbitos, inconsistências, JSON histórico e pacote ZIP.
- Na tela **Tratamento e análise**, selecione um ID para habilitar o Excel integral daquele perfil. O arquivo inclui todos os registros filtrados, mesmo que a tela mostre somente 20.
- Arquivos seguem `CVOBITOS_PETROS_[TIPO]_[COMPETENCIA]_[DATA_GERACAO].ext`.

## Testes

Execute com o Node.js corporativo/portátil disponível:

```text
node tests/run-tests.cjs
node tests/xlsx-reader.cjs
node tests/static-checks.cjs
```

Para a verificação de capacidade com 400 mil linhas, execute o Node com memória ampliada:

```text
node --max-old-space-size=2048 tests/large-volume.cjs
```

Também é possível abrir `tests/browser-tests.html` no Edge.

## Limitações da primeira versão

- Suporta `.xlsx`; arquivos `.xls` legados devem ser salvos como `.xlsx`.
- A tabela operacional e a lista de inconsistências exibem no máximo 20 registros; filtros e exportações continuam consultando o universo completo.
- Históricos do schema `1.0`, produzidos com a regra antiga de IDs, devem ser reprocessados. A versão atual utiliza o schema `1.1`.
- Não possui status ou comentários por matrícula, conforme o escopo aprovado.
- A persistência compartilhada exige importação/exportação manual do histórico em HTML puro.
- CPF e demais dados pessoais não são mascarados; os arquivos são de uso interno e não devem ser enviados externamente.
