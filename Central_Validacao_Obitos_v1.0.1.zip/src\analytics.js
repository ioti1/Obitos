(function (root, factory) {
  const deps = typeof module === "object" && module.exports ? { utils: require("./utils.js") } : { utils: root.CVUtils };
  const api = factory(deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVAnalytics = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";

  function ageBand(age) {
    if (age == null || Number.isNaN(Number(age))) return "Não calculada";
    const value = Number(age);
    if (value < 40) return "Até 39";
    if (value < 60) return "40 a 59";
    if (value < 70) return "60 a 69";
    if (value < 80) return "70 a 79";
    if (value < 90) return "80 a 89";
    return "90 ou mais";
  }

  function createAccumulator(sourceCounts) {
    return {
      sourceCounts,
      total: 0, matched: 0, unmatchedReturn: 0, unmatchedBase: 0,
      confirmed: 0, possible: 0, noDeath: 0, newParticipantDeaths: 0,
      recent: 0, presumedCompleted: 0, dependentDeaths: 0, issues: 0,
      ageSum: 0, ageCount: 0,
      distributions: { classificacao: {}, id: {}, situacao: {}, plano: {}, patrocinadora: {}, uf: {}, faixa_etaria: {} }
    };
  }

  function increment(target, label) {
    const key = U.text(label).trim() || "Não informado";
    target[key] = (target[key] || 0) + 1;
  }

  function consume(acc, row) {
    acc.total += 1;
    if (row.matchStatus === "Com correspondência") acc.matched += 1;
    else if (row.matchStatus === "Retorno sem cadastro") acc.unmatchedReturn += 1;
    else if (row.matchStatus === "Cadastro sem retorno") acc.unmatchedBase += 1;
    if (row.classificacao === "Confirmado") acc.confirmed += 1;
    else if (row.classificacao === "Possível") acc.possible += 1;
    else if (row.classificacao === "Sem óbito") acc.noDeath += 1;
    if (row.novoObitoParticipanteId1) acc.newParticipantDeaths += 1;
    if (row.obitoRecente) acc.recent += 1;
    if (row.presumidoDataCompletaId0) acc.presumedCompleted += 1;
    if (row.dependenteComObitoId2) acc.dependentDeaths += 1;
    acc.issues += row.inconsistencias.length;
    if (row.classificacao === "Confirmado" && row.idadeObito != null && Number.isFinite(Number(row.idadeObito))) {
      acc.ageSum += Number(row.idadeObito); acc.ageCount += 1;
    }
    increment(acc.distributions.classificacao, row.classificacao);
    increment(acc.distributions.id, row.id ? `ID ${row.id} · ${row.perfilId}` : "Sem ID");
    increment(acc.distributions.situacao, row.situacao);
    increment(acc.distributions.plano, row.plano);
    increment(acc.distributions.patrocinadora, row.patrocinadora);
    increment(acc.distributions.uf, row.uf);
    increment(acc.distributions.faixa_etaria, ageBand(row.idadeObito));
  }

  function finish(acc) {
    const returned = Number(acc.sourceCounts?.returned || 0);
    return {
      indicators: {
        total_base: Number(acc.sourceCounts?.base || 0),
        total_retorno: returned,
        total_processados: acc.total,
        correspondencias: acc.matched,
        retornos_sem_cadastro: acc.unmatchedReturn,
        cadastros_sem_retorno: acc.unmatchedBase,
        obitos_confirmados: acc.confirmed,
        obitos_possiveis: acc.possible,
        sem_obito: acc.noDeath,
        novos_obitos_participantes_id1: acc.newParticipantDeaths,
        obitos_recentes: acc.recent,
        presumidos_id0_data_completa: acc.presumedCompleted,
        dependentes_id2_com_obito: acc.dependentDeaths,
        taxa_obito_confirmado: acc.total ? acc.confirmed / acc.total : 0,
        taxa_match_cadastral: returned ? acc.matched / returned : 0,
        idade_media_obito: acc.ageCount ? acc.ageSum / acc.ageCount : null,
        inconsistencias: acc.issues
      },
      distributions: acc.distributions
    };
  }

  function summarize(records, sourceCounts) {
    const accumulator = createAccumulator(sourceCounts);
    records.forEach((row) => consume(accumulator, row));
    return finish(accumulator);
  }

  async function summarizeAsync(records, sourceCounts, onProgress) {
    const accumulator = createAccumulator(sourceCounts);
    const chunk = 3000;
    for (let index = 0; index < records.length; index += 1) {
      consume(accumulator, records[index]);
      if (index && index % chunk === 0) {
        onProgress?.({ percent: 100 * index / Math.max(records.length, 1), phase: "Calculando indicadores", detail: `${index} de ${records.length} registros` });
        await U.yieldToMain();
      }
    }
    onProgress?.({ percent: 100, phase: "Indicadores concluídos", detail: `${records.length} registros contabilizados` });
    return finish(accumulator);
  }

  function historyEntry(context, summary) {
    return {
      competencia: context.competence,
      data_processamento: new Date().toISOString(),
      arquivos: { base_cadastral: context.baseName || "", retorno_ph3a: context.returnName || "" },
      hashes: { base_cadastral: context.baseHash || "indisponível", retorno_ph3a: context.returnHash || "indisponível" },
      indicadores: summary.indicators,
      distribuicoes: summary.distributions,
      versao_regras: context.rulesVersion || "1.1.0"
    };
  }

  function upsertHistory(history, entry) {
    const target = history && Array.isArray(history.apuracoes) ? history : { versao_schema: "1.0", apuracoes: [] };
    const index = target.apuracoes.findIndex((item) => item.competencia === entry.competencia);
    if (index >= 0) target.apuracoes[index] = entry; else target.apuracoes.push(entry);
    target.apuracoes.sort((a, b) => String(a.competencia).localeCompare(String(b.competencia)));
    return target;
  }

  return { ageBand, summarize, summarizeAsync, historyEntry, upsertHistory };
});
