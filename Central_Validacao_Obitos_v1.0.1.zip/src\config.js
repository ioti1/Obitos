(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVConfig = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const BASE_COLUMNS = {
    matricula: ["Matrícula Petros", "Matricula Petros", "Matricula", "Matrícula"],
    nome: ["Nome Participante", "Nome", "Participante"],
    patrocinadora: ["Nome Patrocinador", "Patrocinador", "Patrocinadora"],
    dataNascimento: ["Data Nascimento", "Data de Nascimento", "Nascimento"],
    idade: ["Idade"],
    logradouro: ["Logradouro", "Endereço", "Endereco"],
    numero: ["Número", "Numero"],
    complemento: ["Complemento"],
    bairro: ["Bairro"],
    cidade: ["Cidade", "Município", "Municipio"],
    cep: ["CEP"],
    uf: ["UF", "Estado"],
    pais: ["País", "Pais"],
    dataObitoCadastral: ["Data Óbito", "Data Obito", "Data de Óbito", "Data de Obito"],
    plano: ["Nome Plano", "Plano"],
    situacao: ["Situação", "Situacao"],
    tipoBeneficio: ["Tipo Benefício", "Tipo Beneficio", "Benefício", "Beneficio"]
  };

  const RETURN_COLUMNS = {
    id: ["ID", "Tipo ID", "Grupo ID"],
    matricula: ["Matrícula Petros", "Matricula Petros", "Matricula", "Matrícula"],
    nome: ["Nome Participante", "Nome"],
    dataNascimento: ["Data Nascimento", "Data de Nascimento", "Nascimento"],
    cpf: ["CPF"],
    dataObito: ["Data Óbito", "Data Obito"],
    ppe: ["Pessoa Politicamente Exposta", "PPE"],
    cpfEnriquecido: ["CPF_ENRIQUECIDO", "CPF Enriquecido"],
    nomeEnriquecido: ["NOME_ENRIQUECIDO", "Nome Enriquecido"],
    sexoEnriquecido: ["SEXO_ENRIQUECIDO", "Sexo Enriquecido"],
    dataNascEnriquecido: ["DATA_NASC_ENRIQUECIDO", "Data Nasc Enriquecido"],
    ppeEnriquecido: ["PPE_ENRIQUECIDO", "PPE Enriquecido"],
    obitoEnriquecido: ["OBITO_ENRIQUECIDO", "Obito Enriquecido", "Óbito Enriquecido"],
    dataObitoEnriquecido: ["DATA_OBITO_ENRIQUECIDO", "Data Obito Enriquecido"],
    anoObito: ["ANO_OBITO", "Ano Obito", "Ano Óbito"],
    nomeOrgao: ["NOME_ORGAO", "Nome Orgao", "Nome Órgão"],
    descricaoFuncao: ["DESCRICAO_FUNCAO", "Descricao Funcao", "Descrição Função"],
    dataInicioExercicio: ["DATA_INICIO_EXERCICIO", "Data Inicio Exercicio"],
    dataFimCarreira: ["DATA_FIM_CARREIRA", "Data Fim Carreira"],
    possivelObitoEnriquecido: ["POSSIVEL_OBITO_ENRIQUECIDO", "Possivel Obito Enriquecido"],
    dataPossivelObitoEnriquecido: ["DATA_POSSIVEL_OBITO_ENRIQUECIDO", "Data Possivel Obito Enriquecido"],
    anoPossivelObitoEnriquecido: ["ANO_POSSIVEL_OBITO_ENRIQUECIDO", "Ano Possivel Obito Enriquecido"]
  };

  const ID_PROFILES = {
    "0": "Óbitos presumidos",
    "1": "Participantes",
    "2": "Dependentes ou vinculados"
  };

  return {
    APP_NAME: "Central de Validação de Óbitos",
    VERSION: "1.0.1",
    RULES_VERSION: "1.1.0",
    HISTORY_SCHEMA: "1.1",
    BASE_COLUMNS,
    RETURN_COLUMNS,
    ID_PROFILES,
    ESSENTIAL_BASE: ["matricula"],
    ESSENTIAL_RETURN: ["id", "matricula", "obitoEnriquecido", "dataObitoEnriquecido", "anoObito", "possivelObitoEnriquecido", "dataPossivelObitoEnriquecido", "anoPossivelObitoEnriquecido"],
    AFFIRMATIVE_VALUES: ["SIM", "S", "1", "X", "TRUE", "VERDADEIRO"],
    RECENT_DAYS: 365,
    MAX_AGE: 120,
    INTERNAL_NOTICE: "USO INTERNO - Dados pessoais sob gestão da equipe de Cadastro/Inteligência Cadastral."
  };
});
