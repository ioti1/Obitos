const assert = require("node:assert/strict");
const Validation = require("../src/validation.js");
const Rules = require("../src/rules.js");
const Analytics = require("../src/analytics.js");

const TOTAL = 400000;
const returnHeaders = [
  "ID", "Matrícula Petros", "OBITO_ENRIQUECIDO", "DATA_OBITO_ENRIQUECIDO", "ANO_OBITO",
  "POSSIVEL_OBITO_ENRIQUECIDO", "DATA_POSSIVEL_OBITO_ENRIQUECIDO", "ANO_POSSIVEL_OBITO_ENRIQUECIDO"
];

(async () => {
  const started = Date.now();
  let baseRows = [["Matrícula Petros", "Nome Participante"]];
  let returnRows = [returnHeaders];
  for (let index = 0; index < TOTAL; index += 1) {
    const matricula = String(index + 1).padStart(7, "0");
    baseRows.push([matricula, `Pessoa ${index + 1}`]);
    returnRows.push([String(index % 3), matricula, index % 20 === 0 ? "SIM" : "", "", "", "", "", ""]);
  }

  const baseProgress = [], returnProgress = [], processProgress = [], analyticsProgress = [];
  const base = await Validation.analyzeAsync("base", baseRows, { filename: "qlik_2026-07.xlsx", competence: "2026-07" }, (item) => baseProgress.push(item.percent));
  const returned = await Validation.analyzeAsync("return", returnRows, { filename: "ph3a_2026-07.xlsx", competence: "2026-07" }, (item) => returnProgress.push(item.percent));
  baseRows = null; returnRows = null;

  const records = await Rules.processAsync(base.rows, returned.rows, {}, (item) => processProgress.push(item.percent));
  const summary = await Analytics.summarizeAsync(records, { base: base.rowCount, returned: returned.rowCount }, (item) => analyticsProgress.push(item.percent));

  assert.equal(records.length, TOTAL);
  assert.equal(summary.indicators.total_processados, TOTAL);
  assert.equal(summary.indicators.obitos_confirmados, TOTAL / 20);
  assert.equal(baseProgress.at(-1), 100);
  assert.equal(returnProgress.at(-1), 100);
  assert.equal(processProgress.at(-1), 100);
  assert.equal(analyticsProgress.at(-1), 100);

  const elapsed = ((Date.now() - started) / 1000).toFixed(1);
  console.log(`✓ Cenário de ${TOTAL.toLocaleString("pt-BR")} linhas aprovado em ${elapsed}s.`);
})();
