(function (root, factory) {
  const deps = typeof module === "object" && module.exports
    ? { config: require("./config.js"), utils: require("./utils.js") }
    : { config: root.CVConfig, utils: root.CVUtils };
  const api = factory(deps.config, deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVRules = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (Config, U) {
  "use strict";

  function affirmative(value, accepted) {
    const normalized = U.normalizeText(value);
    return (accepted || Config.AFFIRMATIVE_VALUES).map(U.normalizeText).includes(normalized);
  }

  function chooseDeathDate(record, classification) {
    if (classification === "Confirmado") {
      const full = U.parseDate(record.dataObitoEnriquecido);
      if (full) return { date: full, precision: "data completa", source: "DATA_OBITO_ENRIQUECIDO" };
      if (U.isValidYear(record.anoObito)) return { date: null, year: Number(String(record.anoObito).match(/\d{4}/)[0]), precision: "ano", source: "ANO_OBITO" };
      const cadastral = U.parseDate(record.dataObitoCadastral);
      if (cadastral) return { date: cadastral, precision: "referência cadastral", source: "Data Óbito cadastral" };
    }
    if (classification === "Possível") {
      const full = U.parseDate(record.dataPossivelObitoEnriquecido);
      if (full) return { date: full, precision: "data completa", source: "DATA_POSSIVEL_OBITO_ENRIQUECIDO" };
      if (U.isValidYear(record.anoPossivelObitoEnriquecido)) return { date: null, year: Number(String(record.anoPossivelObitoEnriquecido).match(/\d{4}/)[0]), precision: "ano", source: "ANO_POSSIVEL_OBITO_ENRIQUECIDO" };
    }
    return { date: null, year: null, precision: "não informada", source: "-" };
  }

  function classifyDeath(record, options) {
    const accepted = options?.affirmativeValues || Config.AFFIRMATIVE_VALUES;
    const confirmedEvidence = [];
    if (affirmative(record.obitoEnriquecido, accepted)) confirmedEvidence.push("flag de óbito enriquecido");
    if (U.parseDate(record.dataObitoEnriquecido)) confirmedEvidence.push("data de óbito enriquecida válida");
    if (U.isValidYear(record.anoObito)) confirmedEvidence.push("ano de óbito informado");
    let classification = "Sem óbito";
    let evidence = confirmedEvidence;
    if (confirmedEvidence.length) classification = "Confirmado";
    else {
      const possibleEvidence = [];
      if (affirmative(record.possivelObitoEnriquecido, accepted)) possibleEvidence.push("flag de possível óbito");
      if (U.parseDate(record.dataPossivelObitoEnriquecido)) possibleEvidence.push("data de possível óbito válida");
      if (U.isValidYear(record.anoPossivelObitoEnriquecido)) possibleEvidence.push("ano de possível óbito informado");
      if (possibleEvidence.length) { classification = "Possível"; evidence = possibleEvidence; }
    }
    const deathDate = chooseDeathDate(record, classification);
    return { classification, evidence, ...deathDate };
  }

  function merge(base, returned, options) {
    const source = { ...(base || {}), ...(returned || {}) };
    const death = classifyDeath(source, options);
    const birth = U.parseDate(returned?.dataNascEnriquecido) || U.parseDate(returned?.dataNascimento) || U.parseDate(base?.dataNascimento);
    const exactAge = death.date && birth ? U.ageAt(birth, death.date) : null;
    const maxAge = Number(options?.maxAge || Config.MAX_AGE);
    const deathISO = U.dateToISO(death.date);
    const recentDays = Number(options?.recentDays || Config.RECENT_DAYS);
    const recentCutoff = new Date(); recentCutoff.setUTCDate(recentCutoff.getUTCDate() - recentDays);
    const id = String(returned?.id || "").trim();
    const nome = returned?.nomeEnriquecido || returned?.nome || base?.nome || "";
    const matchStatus = base && returned ? "Com correspondência" : returned ? "Retorno sem cadastro" : "Cadastro sem retorno";
    const inconsistencies = [];
    if (!base && returned) inconsistencies.push("Retorno sem correspondência cadastral");
    if (base && !returned) inconsistencies.push("Cadastro sem retorno Ph3a");
    if (exactAge != null && (exactAge < 0 || exactAge > maxAge)) inconsistencies.push("Idade de óbito fora do limite configurado");
    if (returned && !["0", "1", "2"].includes(id)) inconsistencies.push("ID fora de 0, 1 e 2");
    if (base && returned && U.normalizeText(base.nome) && U.normalizeText(returned.nome) && U.normalizeText(base.nome) !== U.normalizeText(returned.nome)) inconsistencies.push("Divergência de nome entre as bases");
    return {
      matricula: U.normalizeMatricula(returned?.matricula || base?.matricula),
      nome,
      nomeBusca: U.normalizeText(nome),
      cpf: returned?.cpfEnriquecido || returned?.cpf || "",
      id,
      perfilId: Config.ID_PROFILES[id] || "ID não informado",
      patrocinadora: base?.patrocinadora || "Não informado",
      plano: base?.plano || "Não informado",
      situacao: base?.situacao || "Não informado",
      uf: base?.uf || "Não informado",
      dataNascimento: U.dateToISO(birth),
      classificacao: death.classification,
      dataObito: deathISO,
      anoObito: death.year || (death.date ? death.date.getUTCFullYear() : ""),
      precisaoDataObito: death.precision,
      fonteDataObito: death.source,
      idadeObito: exactAge,
      evidencias: death.evidence.join("; ") || "Nenhum indício identificado",
      matchStatus,
      novoObitoParticipanteId1: id === "1" && death.classification === "Confirmado",
      presumidoDataCompletaId0: id === "0" && death.classification === "Confirmado" && death.precision === "data completa",
      dependenteComObitoId2: id === "2" && death.classification !== "Sem óbito",
      obitoRecente: death.date ? death.date >= recentCutoff : false,
      inconsistencias: inconsistencies
    };
  }

  function process(baseRows, returnRows, options) {
    const baseMap = new Map();
    const returnMap = new Map();
    baseRows.forEach((row) => {
      const key = U.normalizeMatricula(row.matricula);
      if (key && !baseMap.has(key)) baseMap.set(key, row);
    });
    returnRows.forEach((row) => {
      const key = U.normalizeMatricula(row.matricula);
      if (key && !returnMap.has(key)) returnMap.set(key, row);
    });
    const keys = new Set([...baseMap.keys(), ...returnMap.keys()]);
    return [...keys].map((key, index) => ({ ...merge(baseMap.get(key), returnMap.get(key), options), __index: index }));
  }

  async function processAsync(baseRows, returnRows, options, onProgress) {
    const baseMap = new Map();
    const returnMap = new Map();
    const chunk = 2500;
    const report = (percent, phase, detail) => onProgress?.({ percent, phase, detail });

    report(0, "Indexando base cadastral", `0 de ${baseRows.length} linhas`);
    for (let index = 0; index < baseRows.length; index += 1) {
      const row = baseRows[index];
      const key = U.normalizeMatricula(row.matricula);
      if (key && !baseMap.has(key)) baseMap.set(key, row);
      if (index && index % chunk === 0) {
        report(28 * index / Math.max(baseRows.length, 1), "Indexando base cadastral", `${index} de ${baseRows.length} linhas`);
        await U.yieldToMain();
      }
    }

    report(28, "Indexando retorno Ph3a", `0 de ${returnRows.length} linhas`);
    for (let index = 0; index < returnRows.length; index += 1) {
      const row = returnRows[index];
      const key = U.normalizeMatricula(row.matricula);
      if (key && !returnMap.has(key)) returnMap.set(key, row);
      if (index && index % chunk === 0) {
        report(28 + (27 * index / Math.max(returnRows.length, 1)), "Indexando retorno Ph3a", `${index} de ${returnRows.length} linhas`);
        await U.yieldToMain();
      }
    }

    const records = [];
    const baseTotal = baseMap.size;
    const estimatedTotal = Math.max(baseTotal + returnMap.size, 1);
    report(55, "Cruzando matrículas", `0 de aproximadamente ${estimatedTotal} registros`);
    let index = 0;
    for (const [key, base] of baseMap) {
      const row = { ...merge(base, returnMap.get(key), options), __index: records.length };
      records.push(row);
      returnMap.delete(key);
      if (index && index % chunk === 0) {
        report(55 + (35 * index / Math.max(baseTotal, 1)), "Cruzando matrículas", `${index} de ${baseTotal} cadastros`);
        await U.yieldToMain();
      }
      index += 1;
    }

    const unmatchedTotal = returnMap.size;
    index = 0;
    for (const returned of returnMap.values()) {
      records.push({ ...merge(null, returned, options), __index: records.length });
      if (index && index % chunk === 0) {
        report(90 + (10 * index / Math.max(unmatchedTotal, 1)), "Incluindo retornos sem cadastro", `${index} de ${unmatchedTotal} retornos`);
        await U.yieldToMain();
      }
      index += 1;
    }
    report(100, "Cruzamento concluído", `${records.length} registros consolidados`);
    return records;
  }

  return { affirmative, chooseDeathDate, classifyDeath, merge, process, processAsync };
});
