(function (root, factory) {
  const deps = typeof module === "object" && module.exports ? { utils: require("./utils.js") } : { utils: root.CVUtils };
  const api = factory(deps.utils);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVTable = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";

  function select(records, filters) {
    const search = U.normalizeText(filters?.search || "");
    const classification = String(filters?.classification || "");
    const id = String(filters?.id || "");
    const maximum = Math.max(1, Number(filters?.limit || 20));
    const direct = [], exact = [], partial = [];
    let directTotal = 0, exactTotal = 0, partialTotal = 0;

    for (const row of records || []) {
      if ((classification && row.classificacao !== classification) || (id && row.id !== id)) continue;
      if (!search) {
        directTotal += 1;
        if (direct.length < maximum) direct.push(row);
        continue;
      }
      const name = row.nomeBusca || U.normalizeText(row.nome);
      if (name === search) {
        exactTotal += 1;
        if (exact.length < maximum) exact.push(row);
      } else if (name.includes(search)) {
        partialTotal += 1;
        if (partial.length < maximum) partial.push(row);
      }
    }

    if (!search) return { rows: direct, total: directTotal, exactName: false };
    if (exactTotal) return { rows: exact, total: exactTotal, exactName: true };
    return { rows: partial, total: partialTotal, exactName: false };
  }

  return { select };
});
