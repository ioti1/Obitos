const assert = require("node:assert/strict");
const U = require("../src/utils.js");
const Rules = require("../src/rules.js");
const Validation = require("../src/validation.js");
const Analytics = require("../src/analytics.js");
const Table = require("../src/table.js");

const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test("normaliza matrícula sem remover zeros à esquerda", () => assert.equal(U.normalizeMatricula(" 000 123 "), "000123"));
test("reconhece cabeçalho ignorando acento, caixa e espaços", () => assert.equal(U.normalizeHeader("  Matrícula   Petros "), "MATRICULA PETROS"));
test("interpreta data DD/MM/AAAA", () => assert.equal(U.dateToISO(U.parseDate("03/07/2026")), "2026-07-03"));
test("interpreta data ISO", () => assert.equal(U.dateToISO(U.parseDate("2026-07-03")), "2026-07-03"));
test("interpreta serial Excel", () => assert.equal(U.dateToISO(U.parseDate("45444")), "2024-06-01"));
test("não trata ano isolado como data completa", () => assert.equal(U.parseDate("2024"), null));
test("confirma óbito por flag", () => assert.equal(Rules.classifyDeath({ obitoEnriquecido: "sim" }).classification, "Confirmado"));
test("confirma óbito por data válida", () => assert.equal(Rules.classifyDeath({ dataObitoEnriquecido: "01/01/2025" }).classification, "Confirmado"));
test("confirma óbito por ano", () => assert.equal(Rules.classifyDeath({ anoObito: "2025" }).classification, "Confirmado"));
test("classifica possível somente sem confirmação", () => assert.equal(Rules.classifyDeath({ possivelObitoEnriquecido: "X" }).classification, "Possível"));
test("prioriza confirmação sobre possível", () => assert.equal(Rules.classifyDeath({ obitoEnriquecido: "1", possivelObitoEnriquecido: "SIM" }).classification, "Confirmado"));
test("marca novo óbito de participante ID 1", () => assert.equal(Rules.merge({ matricula: "001" }, { matricula: "001", id: "1", obitoEnriquecido: "SIM" }).novoObitoParticipanteId1, true));
test("marca data completa localizada para presumido ID 0", () => assert.equal(Rules.merge({ matricula: "001" }, { matricula: "001", id: "0", dataObitoEnriquecido: "01/01/2025" }).presumidoDataCompletaId0, true));
test("marca óbito de dependente ID 2", () => assert.equal(Rules.merge({ matricula: "001" }, { matricula: "001", id: "2", possivelObitoEnriquecido: "SIM" }).dependenteComObitoId2, true));
test("marca retorno sem correspondência", () => assert.equal(Rules.merge(null, { matricula: "999", id: "1" }).matchStatus, "Retorno sem cadastro"));
test("calcula idade apenas com datas completas", () => {
  const full = Rules.merge({ matricula: "001", dataNascimento: "10/01/1950" }, { matricula: "001", id: "0", dataObitoEnriquecido: "09/01/2020" });
  const year = Rules.merge({ matricula: "002", dataNascimento: "10/01/1950" }, { matricula: "002", id: "0", anoObito: "2020" });
  assert.equal(full.idadeObito, 69); assert.equal(year.idadeObito, null);
});
test("identifica duplicidade de matrícula", () => assert.deepEqual(Validation.duplicateValues([{ matricula: "001" }, { matricula: "001" }], "matricula"), [{ value: "001", count: 2 }]));
test("bloqueia arquivo sem coluna essencial", () => {
  const result = Validation.analyze("base", [["Nome Participante"], ["Ana"]], {});
  assert.equal(result.blocking, true); assert.deepEqual(result.missingEssential, ["matricula"]);
});
test("reconhece IDs inválidos", () => {
  const headers = ["ID", "Matrícula Petros", "OBITO_ENRIQUECIDO", "DATA_OBITO_ENRIQUECIDO", "ANO_OBITO", "POSSIVEL_OBITO_ENRIQUECIDO", "DATA_POSSIVEL_OBITO_ENRIQUECIDO", "ANO_POSSIVEL_OBITO_ENRIQUECIDO"];
  const result = Validation.analyze("return", [headers, ["3", "001", "", "", "", "", "", ""]], {});
  assert.equal(result.invalidIds.length, 1); assert.equal(result.blocking, false);
});
test("aceita exclusivamente IDs 0, 1 e 2", () => {
  ["0", "1", "2"].forEach((id) => assert.equal(Rules.merge({ matricula: id }, { matricula: id, id }).inconsistencias.some((issue) => issue.includes("ID fora")), false));
});
test("calcula indicadores principais", () => {
  const rows = [Rules.merge({ matricula: "001" }, { matricula: "001", id: "1", obitoEnriquecido: "SIM" }), Rules.merge({ matricula: "002" }, { matricula: "002", id: "2", possivelObitoEnriquecido: "SIM" })];
  const summary = Analytics.summarize(rows, { base: 2, returned: 2 });
  assert.equal(summary.indicators.obitos_confirmados, 1); assert.equal(summary.indicators.obitos_possiveis, 1); assert.equal(summary.indicators.novos_obitos_participantes_id1, 1); assert.equal(summary.indicators.dependentes_id2_com_obito, 1);
});
test("processamento assíncrono informa progresso e mantém índices", async () => {
  const progress = [];
  const rows = await Rules.processAsync([{ matricula: "001" }], [{ matricula: "001", id: "1", obitoEnriquecido: "SIM" }], {}, (item) => progress.push(item.percent));
  assert.equal(rows.length, 1); assert.equal(rows[0].__index, 0); assert.equal(progress.at(-1), 100);
});
test("tabela limita a visualização aos 20 primeiros registros", () => {
  const records = Array.from({ length: 35 }, (_, index) => ({ nome: `Pessoa ${index + 1}`, nomeBusca: `PESSOA ${index + 1}`, id: "1", classificacao: "Confirmado" }));
  const result = Table.select(records, { limit: 20 });
  assert.equal(result.total, 35); assert.equal(result.rows.length, 20); assert.equal(result.rows[0].nome, "Pessoa 1");
});
test("filtros de ID e classificação usam o universo completo e retornam no máximo 20", () => {
  const records = Array.from({ length: 60 }, (_, index) => ({ nome: `Pessoa ${index + 1}`, id: index < 45 ? "2" : "1", classificacao: index % 2 ? "Confirmado" : "Possível" }));
  const result = Table.select(records, { id: "2", classification: "Confirmado", limit: 20 });
  assert.equal(result.total, 22); assert.equal(result.rows.length, 20);
});
test("busca exata por nome isola somente o participante ou dependente", () => {
  const records = [{ nome: "Ana Lima", id: "1" }, { nome: "Ana Lima Souza", id: "2" }, { nome: "Ana Lima", id: "0" }];
  const result = Table.select(records, { search: "Ana Lima", limit: 20 });
  assert.equal(result.exactName, true); assert.equal(result.total, 2); assert.deepEqual(result.rows.map((row) => row.nome), ["Ana Lima", "Ana Lima"]);
});
test("histórico substitui competência reprocessada", () => {
  const history = Analytics.upsertHistory({ versao_schema: "1.0", apuracoes: [] }, { competencia: "2026-06", indicadores: { total_processados: 1 } });
  Analytics.upsertHistory(history, { competencia: "2026-06", indicadores: { total_processados: 2 } });
  assert.equal(history.apuracoes.length, 1); assert.equal(history.apuracoes[0].indicadores.total_processados, 2);
});

(async () => {
  let passed = 0;
  for (const item of tests) {
    try { await item.fn(); passed += 1; console.log(`✓ ${item.name}`); }
    catch (error) { console.error(`✗ ${item.name}`); console.error(error); process.exitCode = 1; }
  }
  console.log(`\n${passed}/${tests.length} testes aprovados.`);
})();
