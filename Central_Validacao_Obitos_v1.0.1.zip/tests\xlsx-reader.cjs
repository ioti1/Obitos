const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { resolve } = require("node:path");

global.JSZip = require("../vendor/jszip.min.js");
const Xlsx = require("../src/xlsx.js");

(async () => {
  const source = resolve(__dirname, "../../outputs/validacao_obitos_exemplos_20260712/CVOBITOS_PETROS_RETORNO_PH3A_2026-07_2026-07-12.xlsx");
  const bytes = readFileSync(source);
  const file = {
    name: "CVOBITOS_PETROS_RETORNO_PH3A_2026-07_2026-07-12.xlsx",
    arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
  };
  const progress = [];
  const workbook = await Xlsx.read(file, (item) => progress.push(item.percent));
  const rows = workbook.Retorno_Ph3a;
  assert.equal(rows.length, 16);
  assert.deepEqual(rows[0].slice(0, 5), ["ID", "Matrícula Petros", "Nome Participante", "Data Nascimento", "CPF"]);
  assert.deepEqual(rows.slice(1, 5).map((row) => row[0]), ["1", "0", "1", "2"]);
  assert.deepEqual(rows.slice(1, 3).map((row) => row[1]), ["000001", "000002"]);
  assert.equal(progress.at(-1), 100);
  assert.ok(progress.length >= 5);
  console.log(`✓ Leitura incremental XLSX aprovada: ${rows.length - 1} registros e ${progress.length} atualizações de progresso.`);
})();
